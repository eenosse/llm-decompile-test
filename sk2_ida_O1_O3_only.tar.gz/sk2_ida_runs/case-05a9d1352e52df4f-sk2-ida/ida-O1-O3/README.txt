Files in this trial

status.txt              final validity/completion status
ida_pseudo.jsonl        raw per-function Hex-Rays output from IDA
ida.stdout              IDA stdout
ida.stderr              IDA stderr
dataset.json            normalized SK2 inference dataset
normalized_stats.txt    dataset preparation counts
sk2.stdout              SK2 inference stdout
sk2.stderr              SK2 inference stderr
sk2_output/             SK2 generated functions and logs

The parent output manifest is evaluator-only metadata.
