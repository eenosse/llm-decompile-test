main(intargc, char** argv) {
  hashtableht = {0, 0, 0, NULL};
  ht.size = 8;
  for (inti = 0; i != 20; ++i) {
    doublevalue = 1.5 + i % 5;
    constchar* key = keys[i];
    hashnode* node = hash_get(&ht, key);
    if (node) {
      ++node->count;
      node->value += value;
    } else {
      unsignedoldsize = ht.size;
      if (ht.used * 4 >= ht.size * 3) {
        unsignednewsize = ht.size * 2;
        hashnode** newnodes = calloc(newsize, sizeof(hashnode*));
        if (!newnodes) exit(1);
        unsignedj = 0;
        if (oldsize) {
          do {
            hashnode* oldnode = ht.nodes[j];
            hashnode** newnode;
            while (oldnode) {
              newnode = newnodes + (oldnode->hash & (newsize - 1));
              hashnode* oldnode2 = oldnode;
              oldnode = oldnode->next;
              *newnode = oldnode2;
            }
          } while (++j < oldsize);
        }
        free(ht.nodes);
        ht.nodes = newnodes;
        ht.size = newsize;
        ht.rehash++;
      }
      node = hash_node_new(key, oldsize = strlen(key));
      unsignedhash = node->hash & (oldsize - 1);
      hashnode* newnode = calloc(1, sizeof(hashnode) + oldsize);
      if (!newnode) exit(1);
      memcpy(newnode + 1, key, oldsize + 1);
      newnode->key = oldsize;
      newnode->hash = node->hash;
      newnode->count = 1;
      newnode->value = value;
      newnode->data = i % 3;
      node = ht.nodes[hash];
      if (node) ht.used++;
      newnode->next = node;
      ht.nodes[hash] = newnode;
      ht.used++;
    }
  }
  for (unsignedj = 0; j < ht.size; ++j) {
    hashnode* node = ht.nodes[j];
    if (node) {
      printf("[%u]", j);
      while (node) {
        printf("%s", node->key);
        node = node->next;
      }
      putc('\n', stdout);
    }
  }
  hash_free(&ht);
  node = hash_get(&ht, "app.js");
  if (node) printf("app.js:%d\n", node->count);
  node = hash_get(&ht, "nope.txt");
  if (node) printf("nope.txt:%d\n", node->count);
  hash_remove(&ht, "api/users");
  hash_remove(&ht, "nope.txt");
  hash_free(&ht);
  for (unsignedj = 0; j < ht.size; ++j) {
    hashnode* node = ht.nodes[j];
    while (node) {
      hashnode* oldnode2 = node;
      node = node->next;
      free(oldnode2);
    }
  }
  free(ht.nodes);
  return0;
}