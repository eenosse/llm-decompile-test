hash_key(unsignedchar* a, unsignedlonglen) {
  unsignedinth = 4283789119U;
  unsignedlongi;
  for (i = 0; i < len; i++) {
    h *= 16777619U;
    h ^= a[i];
  }
  h ^= h >> 15;
  returnh;
}