cmp_bucket(void* a, void* b) {
  if (*(int*)a == *(int*)b) {
    return *((int*)a + 1) - *((int*)b + 1);
  } else {
    return *(int*)b - *(int*)a;
  }
}