ht_stats(Graph* graph) {
  unsignedintvertices = graph->vertices;
  Vertex* vertex = calloc(vertices, sizeof(Vertex));
  if (vertex == NULL) {
    exit(1);
  }
  for (unsignedinti = 0; i < vertices; i++) {
    vertex[i].id = i;
    AdjList* adjlist = graph->adjlist[i];while(adjlist