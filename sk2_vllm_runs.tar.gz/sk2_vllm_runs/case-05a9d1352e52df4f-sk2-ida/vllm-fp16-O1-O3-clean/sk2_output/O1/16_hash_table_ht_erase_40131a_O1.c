ht_erase(Hash* hash, constchar* key) {
  inthashval = func2(key, strlen(key));
  intindex = hashval & (hash->size - 1);
  Node* node = hash->table[index];
  if (node == NULL) return0;
  do {
    if (node->hashval == hashval && !strcmp(node->key, key)) {
      hash->table[index] = node->next;
      free(node);
      hash->count--;
      return1;
    }
    node = node->next;
  } while (node != NULL);
  return0;
}