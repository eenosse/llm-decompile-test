*ht_lookup(Hash* hash, constchar* key) {
  inthashcode = _HashCode(key, strlen(key));
  intindex = hashcode & (hash->size - 1);
  HashNode* node = hash->table[index];
  intcount = 0;
  while (node != NULL) {
    count++;
    if (node->hashcode == hashcode && !strcmp(node->key, key)) {
      break;
    }
    node = node->next;
  }
  hash->finds += count;
  returnnode;
}