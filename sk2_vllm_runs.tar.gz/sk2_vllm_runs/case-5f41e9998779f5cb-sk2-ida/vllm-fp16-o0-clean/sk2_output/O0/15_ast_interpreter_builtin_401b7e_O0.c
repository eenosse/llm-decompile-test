builtin(FILE* f, char* func, doublex, doubley, doublez, doublew, doubleu,
        doublev, doublep, doubleq, doubler, doublet, intdim, doubleh,
        unsignedlonglongid) {
  doubleval;
  if (!strcmp(func, "abs")) {
    if (x < 0) val = -x;
    elseval = x;
  }
  elseif(!strcmp(func, "sqr")) {
    fprintf(f, x * x);
    return1;
  }
  elseif(!strcmp(func, "len")) {
    if (dim == 2) {
      if (id & 0x8000000000000000LL)
        val = (double)((int)(id >> 1) | (int)(id & 1));
      elseval = (double)id;
    }
    elseval = 0.0;
  }
  else {
    fprintf(f);
    return1;
  }
}
else {
  val = 0.0;
}
}
fprintf(f, val);
return1;
}