mk_bool(intarg1) {
  1var2;
  var2.field1 = 1;
  var2.field2 = arg1;
  returnvar2;
}