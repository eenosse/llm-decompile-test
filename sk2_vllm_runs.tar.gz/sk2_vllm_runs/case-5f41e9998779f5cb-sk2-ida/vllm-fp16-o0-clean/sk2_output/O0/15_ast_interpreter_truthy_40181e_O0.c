truthy(void* p) {
  intt;
  t = *(int*)p;
  switch (t) {
  case0:
    return *(double*)(p + 8) != 0.0;
  case1:
    return *(int*)(p + 8);
  case2:
    return *(void**)(p + 16) != NULL;
  case3:
    return0;
  }
  return0;
}