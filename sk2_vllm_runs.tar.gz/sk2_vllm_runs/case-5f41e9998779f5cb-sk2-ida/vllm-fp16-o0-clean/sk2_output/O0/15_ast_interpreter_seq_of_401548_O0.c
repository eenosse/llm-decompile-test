seq_of(unsignedchar** scan, int n) {
  unsignedchar* out;
  int i, m;
  m = n;
  out = _jpeg_alloc(6);
  if (n > 8) m = 8;
  for (i = 0; i < m; i++) out[2 + 2 * i] = scan[i][0];
  out[72] = m;
  returnout;
}