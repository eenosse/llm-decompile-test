*unary(inttype, node* left_child) {
  node* new_node = _new_node(2);
  new_node->children[1] = type;
  new_node->children[2] = left_child;
  returnnew_node;
}