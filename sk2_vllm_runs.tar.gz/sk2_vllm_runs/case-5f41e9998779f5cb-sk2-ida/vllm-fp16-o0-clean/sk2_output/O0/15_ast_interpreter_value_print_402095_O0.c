value_print(node* n) {
  intt = n->type;
  if (t == 3) {
    printf("nil");
    return;
  }
  if (t > 3) {
    return;
  }
  if (t == 2) {
    printf("\"%s\"(%zu)", n->s, n->sl);
    return;
  }
  if (t == 0) {
    printf("%.4f", n->d);
    return;
  }
  if (t == 1) {
    char* b = n->d ? "true" : "false";
    printf("%s", b);
    return;
  }
}