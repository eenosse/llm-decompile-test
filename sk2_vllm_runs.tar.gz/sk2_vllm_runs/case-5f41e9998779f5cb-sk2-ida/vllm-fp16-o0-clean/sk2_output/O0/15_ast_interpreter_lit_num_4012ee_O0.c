lit_num(doublez) {
  double* __result__ = _mm_alloc(0);
  __result__[2] = 0.0;
  __result__[3] = z;
  return__result__;
}