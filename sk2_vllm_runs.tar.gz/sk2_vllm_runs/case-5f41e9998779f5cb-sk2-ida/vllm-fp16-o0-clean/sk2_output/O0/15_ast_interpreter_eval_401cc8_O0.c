*eval(_l_value* dest, _l_value* src, _l_value* env) {
  env->refcount++;
  switch (src->type) {
  case0:
    *dest = *src;
    break;
  case1 : {
    _l_value* tmp = eval_get(env, src->name);
    if (tmp) {
      *dest = *tmp;
    } else {
      _l_value_null(dest);
    }
  } break;
  case2:
    eval(dest, src->name, env);
    if (src->value == 9) {
      _l_value_int(dest, -src->value);
    } else {
      _l_value_bool(dest, !_l_value_is_false(dest));
    }
    break;
  case3:
    eval(dest, src->name, env);
    eval(dest, src->next, env);
    _l_value_op(dest, src->value, src->value);
    break;
  case4:
    if (src->is_if) {
      eval(dest, src->next, env);
    } else {
      _l_value_null(dest);
    }
    _l_value_print(dest, src->value);
    break;
  case5:
    eval(dest, src->value, env);
    if (_l_value_is_false(dest)) {
      eval(dest, src->name, env);
    }
    elseif(src->next) { eval(dest, src->next, env); }
    else {
      _l_value_null(dest);
    }
    break;
  case6:
    _l_value_null(dest);
    for (inti = 0; i < src->count; i++) {
      _l_value_tmp;
      eval(&tmp, src->args[i], env);
      *dest = tmp;
    }
    *dest = *dest;
    break;
  case7:
    eval(dest, src->next, env);
    _l_value* tmp = eval_get(env, src->value);
    if (tmp) {
      *tmp = *dest;
    }
    *dest = *dest;
    break;
    default:
      _l_value_null(dest);
      break;
  }
  returndest;
}