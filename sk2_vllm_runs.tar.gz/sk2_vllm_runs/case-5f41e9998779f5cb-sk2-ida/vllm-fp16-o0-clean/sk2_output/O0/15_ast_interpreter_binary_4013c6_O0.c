binary(inttype, AST* left, AST* right) {
  AST* node = __new_ast_node_node(AST_NODE);
  node->type = type;
  node->left = left;
  node->right = right;
  returnnode;
}
#Whatisthesourcecode ?