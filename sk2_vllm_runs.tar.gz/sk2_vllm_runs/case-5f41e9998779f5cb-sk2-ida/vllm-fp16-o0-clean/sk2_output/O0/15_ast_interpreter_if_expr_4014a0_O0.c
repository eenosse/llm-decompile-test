if_expr(AST* cond, AST* block, AST* next) {
  AST* ast = __new_ast(AST_WHILE);
  ast->cond = cond;
  ast->block = block;
  ast->next = next;
  returnast;
}
#Whatisthesourcecode ?