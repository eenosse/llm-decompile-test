ast_free(node* n) {
  switch (n->type) {
  caseN_STRING:
    if (n->refs == 2) free(n->value);
    break;
  caseN_FUNC:
    func1(n->value);
    break;
  caseN_FUNC_CALL:
    func1(n->value);
    func1(n->next);
    break;
  caseN_ARRAY:
    for (unsignedchari = 0; i < n->array_size; i++) func1(n->array[i]);
    break;
  caseN_VAR:
    func1(n->var);
    func1(n->value);
    if (n->next) func1(n->next);
    break;
  caseN_VAR_ARRAY:
    for (unsignedchari = 0; i < n->var_array_size; i++) func1(n->var[i]);
    break;
  caseN_OP:
    func1(n->next);
    break;
  }
  free(n);
}