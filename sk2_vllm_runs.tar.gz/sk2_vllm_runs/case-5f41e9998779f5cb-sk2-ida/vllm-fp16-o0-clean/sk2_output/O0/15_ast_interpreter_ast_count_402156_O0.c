ast_count(AST* t) {
  inti = 1;
  switch (t->type) {
  case2:
    i += func1(t->left);
    break;
  case3:
    i += func1(t->left);
    i += func1(t->right);
    break;
  case4:
    for (intj = 0; j < t->num_children; j++) {
      i += func1(t->children[j]);
    }
    break;
  case5:
    i += func1(t->left);
    i += func1(t->right);
    if (t->third) {
      i += func1(t->third);
    }
    break;
  case6:
    for (intj = 0; j < t->num_statements; j++) {
      i += func1(t->statements[j]);
    }
    break;
  case7:
    i += func1(t->right);
    break;
    default:
      break;
  }
  returni;
}