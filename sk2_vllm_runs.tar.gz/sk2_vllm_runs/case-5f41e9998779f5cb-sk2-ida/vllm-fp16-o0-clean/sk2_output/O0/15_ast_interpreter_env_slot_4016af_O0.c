*env_slot(byte* memory, char* string) {
  inti;
  bytec;
  byte* p;
  for (i = 0; i < memory[160]; i++) {
    if (!strcmp((char*)&memory[i * 40], string)) {
      return &memory[i * 40 + 16];
    }
  }
  if (memory[160] == 16) {
    returnNULL;
  }
  strncpy((char*)&memory[memory[160] * 40], string, 15);
  p = &memory[memory[160] * 40 + 16];
  _strcpy(c);
  *p = c;
  memory[160]++;
  return &memory[memory[160] * 40 + 16];
}