lit_str(constchar* str) {
  AST* ast = ast_new(AST_STRING);
  ast->type = TYPE_STRING;
  ast->value.string = strdup(str);
  ast->value.length = strlen(str);
  returnast;
}