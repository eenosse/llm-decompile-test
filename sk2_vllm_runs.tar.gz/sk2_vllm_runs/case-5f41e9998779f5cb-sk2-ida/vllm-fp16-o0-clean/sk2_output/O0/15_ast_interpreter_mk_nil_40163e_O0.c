mk_nil(void) {
  var1 = {0};
  a.b = 3;
  returna;
}