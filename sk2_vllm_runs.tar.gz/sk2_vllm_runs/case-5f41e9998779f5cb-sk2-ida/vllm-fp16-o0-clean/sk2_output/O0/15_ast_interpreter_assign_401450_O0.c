assign(constchar* file, void* line) {
  void* ptr;
  ptr = __real_malloc(size);
  strncpy(((char*)ptr) + 8, file, 15);
  *(void**)((char*)ptr + 24) = line;
  returnptr;
}