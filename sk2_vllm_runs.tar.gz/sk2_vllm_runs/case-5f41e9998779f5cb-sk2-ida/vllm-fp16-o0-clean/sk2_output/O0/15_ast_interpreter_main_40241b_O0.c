main(intargc, char** argv) {
  char** args = argv;
  doublevars[5];
  vars[0] = _double(12.0);
  vars[1] = _var(
      "x",
      _add(_mul(_pow(_int(2), _int(1, _var("x"), _double(4.0)), _double(3.0))),
           _double(12.0)));
  vars[2] =
      _var("y", _func(_func_int("y", _func_str("abs", _var("x")),
                                _func_str("sqr", _var("x")), _double(20.0)),
                      _int(9, _var("y")), _func_int("len", _var("msg"))));
  vars[3] = _var("msg", _add(_str("ok"), _str("val:")));
  vars[4] = _add(_var("y"), _func_int("len", _var("msg")));
  char** code = _compile(vars, 5);
  unsignedsize = _code_size(code);
  printf("%u\n", size);
  charmem[648];
  memset(mem, 0, 648);
  doubleinput[2] = 20.0;
  unsignedi;
  doubleoutput[2];
  output[0] = 20.0;
  output[1] = 20.0;
  _run(output, code, mem, 20.0);
  for (i = 0; i < 2; i++) {
    output[i] = output[i];
  }
  __print_double(output);
  unsignedj;
  unsignedlen;
  for (j = 0; j < len; j++) {
    printf("%s", mem + j * 40);
    __print_double(mem + j * 40 + 16);
    printf("%d\n", *(unsigned*)(mem + j * 40 + 16));
  }
  for (j = 0; j < len; j++) {
    if (*(unsigned*)(mem + j * 40 + 16) == 2) {
      free(*(char**)(mem + j * 40 + 24));
    }
  }
  _free(code);
  return0;
}