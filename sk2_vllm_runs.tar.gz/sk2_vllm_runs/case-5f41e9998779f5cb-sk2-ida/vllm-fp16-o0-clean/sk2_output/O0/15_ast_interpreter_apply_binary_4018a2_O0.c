apply_binary(void* v, intop, inttype, inttype2, inttype3, inttype4, inttype5,
             doubled1, doubled2, constchar* s1, intslen1, intslen2,
             constchar* s2, size_tslen2) {
  inti;
  intlen;
  char* s;
  if (op == 11 && type5 == 2 && slen2 == 2) {
    len = slen1 + slen2;
    s = malloc(len + 1);
    if (s == NULL) {
      exit(1);
    }
    memcpy(s, s1, slen1);
    memcpy(s + slen1, s2, slen2 + 1);
    v->type = 2;
    v->s = s;
    v->slen = len;
    return;
  }
  switch (op) {
  case0:
    _func2(v, d1 + d2);
    break;
  case1:
    _func2(v, d1 - d2);
    break;
  case2:
    _func2(v, d1 * d2);
    break;
  case3:
    _func2(v, d1 / d2);
    break;
  case4:
    _func3(v, d1 < d2);
    break;
  case5:
    _func3(v, d1 > d2);
    break;
  case6:
    _func3(v, d1 == d2);
    break;
  case7:
    i = _func4(&type5) && _func4(&slen2);
    _func3(v, i);
    break;
  case8:
    i = _func4(&type5) || _func4(&slen2);
    _func3(v, i);
    break;
    default:
      _func5(v);
      break;
  }
}