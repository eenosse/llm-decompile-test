mk_num(t_func1* x, doublea) {
  x->a = 0;
  x->b = a;
  x->c = 0;
}