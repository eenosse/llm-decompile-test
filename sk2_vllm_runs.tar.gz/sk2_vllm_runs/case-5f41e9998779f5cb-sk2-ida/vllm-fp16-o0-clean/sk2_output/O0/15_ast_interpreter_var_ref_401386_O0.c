var_ref(constchar* s) {
  char* r;
  r = __builtin_malloc(1);
  strncpy(r + 8, s, 15);
  returnr;
}