main(intargc, char** argv) {
  inta[4] = {1, 2, 3, 4};
  intb[4] = {5, 6, 7, 8};
  printarray(a);
  printarray(b);
  intc[4] = {1, 2, 3, 4};
  intd[4] = {5, 6, 7, 8};
  inte[4] = {9, 10, 11, 12};
  intf[4] = {13, 14, 15, 16};
  inti;
  for (i = 0; i < 4; i++) {
    printf("a[%d]=%d\n", i, c[i]);
  }
  intsum;
  for (sum = 0; sum < 5; sum++) {
    sum += a[sum];
  }
  printf("Sumofthecharactersinthestringis%d\n", sum);
  for (sum = 0; sum < 5; sum++) {
    printf("a[%d]=%d\n", sum, a[sum]);
  }
  printf("\n");
  printf("Hello,World!\n");
  return0;
}