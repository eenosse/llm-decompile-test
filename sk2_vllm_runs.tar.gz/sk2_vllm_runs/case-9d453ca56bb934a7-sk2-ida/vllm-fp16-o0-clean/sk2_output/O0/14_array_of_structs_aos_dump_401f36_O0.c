aos_dump(_401F36* a1, unsignedlonga2) {
  unsignedlongi;
  for (i = 0; i < a2; i++) {
    printf("%u%u%.2f%.0f%.2f%.2f%.2f%04x%u\n", a1[i].a3, a1[i].a4, a1[i].a5,
           a1[i].a6, a1[i].a7, a1[i].a8, a1[i].a9, a1[i].a10, a1[i].a11);
  }
}