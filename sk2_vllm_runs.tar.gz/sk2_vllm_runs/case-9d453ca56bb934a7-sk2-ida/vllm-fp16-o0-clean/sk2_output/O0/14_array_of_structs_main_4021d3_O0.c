main(intargc, char** argv) {
  doubledata[12];
  doubledata2[12];
  doubledata3[12];
  unsignedi;
  unsignedj;
  unsignedmax;
  unsigneddata4[99];
  unsigneddata5[12 * 40];
  unsigneddata6[12 * 40];
  readdata(data, 12);
  normalize(data, 12);
  sort(data2, data, 12);
  printdata(data2, 12);
  stats(data3, 2.5, "stats", data2, data, 12);
  printdata(data3);
  readdata4(data4, 99);
  for (i = 0; i < 3; i++) {
    shuffle(data4, 0.1);
  }
  max = data4[98];
  for (j = 0; j < max; j += 3) {
    printf("%u%.3f%.3f%.3f%.3f%u\n", data4[j], data4[j + 1], data4[j + 2],
           data4[j + 3], data4[j + 4], data4[j + 5]);
  }
  for (i = 0; i < 12; i++) {
    data6[i * 40] = data[i];
  }
  qsort(data6, 12, 40, compare);
  return0;
}