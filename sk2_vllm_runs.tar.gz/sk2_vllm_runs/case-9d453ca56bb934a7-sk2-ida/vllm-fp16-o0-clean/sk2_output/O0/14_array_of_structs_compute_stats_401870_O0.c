compute_stats(double* out, float* in, unsignedlongn) {
  doublemass = 0.0;
  doubler2, x, y, z, vx, vy, vz;
  unsignedlongi;
  unsignedlongalive;
  doublecount[3];
  unsignedlongalivecount;
  doubleke[2];
  charinfo[48];
  memset(count, 0, 3 * sizeof(double));
  alivecount = 0;
  ke[0] = 1.0e30;
  ke[1] = -1.0e30;
  for (i = 0; i < n; i++) {
    float* p = in + 40 * i;
    r2 = p[12] * p[12] + p[13] * p[13] + p[14] * p[14];
    if (p[39] != 0) {
      alivecount++;
      count[p[38] & 3]++;
      mass += 0.5 * p[24] * r2;
      ke[0] = (ke[0] < p[24]) ? ke[0] : p[24];
      ke[1] = (ke[1] > p[24]) ? ke[1] : p[24];
      y = p[0] * p[24];
      z = p[1] * p[24];
      vx = p[2] * p[24];
      vy = p[3] * p[24];
      vz = p[4] * p[24];
      vz = p[5] * p[24];
      alive = p[5] * p[24];
    }
  }
  if (mass > 0.0) {
    y /= mass;
    z /= mass;
    vx /= mass;
  }
  snprintf(info, 48, "alive=%umass=%.2fke=%.2f", alivecount, mass, ke[0]);
  out[0] = mass;
  out[1] = y;
  out[2] = z;
  out[3] = vx;
  out[4] = vy;
  out[5] = vz;
  out[6] = ke[0];
  out[7] = ke[1];
  out[8] = alivecount;
  out[9] = info;
}