cmp_by_mass_then_id(float* a, float* b) {
  if (b[6] > a[6]) return1;
  if (a[6] > b[6]) return -1;
  if (a[8] < b[8]) return -1;
  if (a[8] > b[8]) return1;
  return0;
}