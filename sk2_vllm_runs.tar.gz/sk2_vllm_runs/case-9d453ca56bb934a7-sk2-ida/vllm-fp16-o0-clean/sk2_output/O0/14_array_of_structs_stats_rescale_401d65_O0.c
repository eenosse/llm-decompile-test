stats_rescale(doublex, t_vector3d, v) {
  inti;
  charstr[48];
  v.x *= x;
  for (i = 0; i < 3; i++) {
    v.y[i] *= x;
    v.z[i] *= x;
  }
  snprintf(str, "scaledx%.2fke=%.2f", x, v.x);
  t.y = v.y;
  t.z = v.z;
  t.str = str;
  returnt;
}