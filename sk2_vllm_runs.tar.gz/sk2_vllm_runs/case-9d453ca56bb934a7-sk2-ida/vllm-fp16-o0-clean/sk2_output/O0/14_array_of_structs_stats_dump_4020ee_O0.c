stats_dump(float* a) {
  printf("%.3f%.3f%.3f%.3f%.3f%.3f%.3f\n", a[0], a[1], a[2], a[3], a[4], a[5],
         a[6]);
  printf("%.2f%.2f%u%u%u%u%u\n", a[7], a[8], (unsignedint)a[9],
         (unsignedint)a[10], (unsignedint)a[11], (unsignedint)a[12],
         (unsignedint)a[13]);
}