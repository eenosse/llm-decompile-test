soa_step(float* x, floatdt) {
  unsignedinti;
  for (i = 0; i < x[99]; i++) {
    x[i] += dt * x[i + 36];
    x[i + 12] += dt * x[i + 48];
    x[i + 24] += dt * x[i + 60];
    x[i + 48] -= dt * 9.81f;
  }
}