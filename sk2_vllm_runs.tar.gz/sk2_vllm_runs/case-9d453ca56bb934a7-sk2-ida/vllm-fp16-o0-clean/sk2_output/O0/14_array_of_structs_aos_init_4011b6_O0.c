aos_init(__V2* param1, unsignedlonglongparam2) {
  unsignedlonglongi;
  for (i = 0; i < param2; i++) {
    __V2* v = param1 + i;
    v->x = i + 500;
    v->y = i * 1.5f;
    v->z = i * i;
    v->w = 0.5f - i % 3;
    v->a = i % 5 * 0.25f;
    v->b = i % 2 - 0.75f;
    v->c = 1.0f + i % 6 * 0.5f;
    v->d = i % 2 ? 1.0f : -2.0f;
    v->e = i | 0x100;
    v->f = i % 3;
    v->g = i % 7 != 6;
  }
}