assign(constchar* file, size_tline) {
  void* ptr;
  ptr = __real_malloc(size);
  strncpy(((char*)ptr) + 8, file, 15);
  *((size_t*)(ptr + 8 + 15)) = line;
  returnptr;
}