call1(constchar* name, value_t* value) {
  const_t* c = _mem_alloc(const_t);
  strncpy(c->name, name, MAX_NAME_LEN - 1);
  c->value = value;
  c->is_const = true;
  returnc;
}