lit_str(constchar* str) {
  AST* ast = newAST(AST_STRING);
  ast->type = TYPE_STRING;
  ast->value.string = strdup(str);
  ast->length = strlen(str);
  returnast;
}