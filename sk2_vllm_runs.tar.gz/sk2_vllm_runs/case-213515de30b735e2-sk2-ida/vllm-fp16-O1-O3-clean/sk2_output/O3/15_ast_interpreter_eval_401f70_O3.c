eval(var3, var2->field3);
if (var7) {
  *var1 = *var7;
  return;
}
}
break;
case2 : {
  type1var8 = func1(var2->field4, var3);
  if (var8.field2 == 9) {
    var1->field2 = 0;
    var1->field5 = -var8.field5;
    return;
  }
  if (var8.field2 == 1) {
    var1->field2 = 1;
    var1->field6 = var8.field6 ? 1 : 0;
    return;
  }
  if (var8.field2 == 2) {
    var1->field2 = 1;
    var1->field6 = var8.field6 ? 1 : 0;
    return;
  }
  var1->field2 = 1;
  var1->field6 = var8.field2 == 0 && var8.field5 == 0.0;
  return;
}
case3 : {
  type1var8 = func1(var2->field4, var3);
  type1var9 = func1(var_name, var3);
  switch (var2->field2) {
  case0:
#Whatisthesourcecode ? #case0 : * var1 = *var2;
    return;
  case1 : {
    type1* var10 = func2(var3, var2->field3);
    if (var10) {
      *var1 = *var10;
      return;
    }
  } break;
  case2 : {
    type1var11 = func1(var2->field4, var3);
    if (var11.field2 == 9) {
      var1->field2 = 0;
      var1->field5 = -var11.field5;
      return;
    }
    if (var11.field2 == 1) {
      var1->field2 = 1;
      var1->field6 = var11.field6 ? 1 : 0;
      return;
    }
    if (var11.field2 == 2) {
      var1->field2 = 1;
      var1->field6 = var11.field6 ? 1 : 0;
      return;
    }
    var1->field2 = 1;
    var1->field6 = var11.field2 == 0 && var11.field5 == 0.0;
    return;
  }
  case3 : {
    type1var11 = func1(var2->field4, var3);
    type1var12 = func1(var_name, var3);
    switch (var2->field2) {
    case0:
#Whatisthesourcecode ? #case0 : * var1 = *var2;
      return;
    case1 : {
      type1* var13 = func2(var3, var2->field3);
      if (var13) {
        *var1 = *var13;
        return;
      }
    } break;
    case2 : {
      type1var14 = func1(var2->field4, var3);
      if (var14.field2 == 9) {
        var1->field2 = 0;
        var1->field5 = -var14.field5;
        return;
      }
      if (var14.field2 == 1) {
        var1->field2 = 1;
        var1->field6 = var14.field6 ? 1 : 0;
        return;
      }
      if (var14.field2 == 2) {
        var1->field2 = 1;
        var1->field6 = var14.field6 ? 1 : 0;
        return;
      }
      var1->field2 = 1;
      var1->field6 = var14.field2 == 0 && var14.field5 == 0.0;
      return;
    }
    case3 : {
      type1var14 = func1(var2->field4, var3);
      type1var15 = func1(var_name, var3);
      switch (var2->field2) {
      case0:
#Whatisthesourcecode ? #case0 : * var1 = *var2;
        return;
      case1 : {
        type1* var16 = func2(var3, var2->field3);
        if (var16) {
          *var1 = *var16;
          return;
        }
      } break;
      case2 : {
        type1var17 = func1(var2->field4, var3);
        if (var17.field2 == 9) {
          var1->field2 = 0;
          var1->field5 = -var17.field5;
          return;
        }
        if (var17.field2 == 1) {
          var1->field2 = 1;
          var1->field6 = var17.field6 ? 1 : 0;
          return;
        }
        if