node_new(intid) {
  Node* n = calloc(1, sizeof(Node));
  if (n == NULL) exit(1);
  n->id = id;
  n->index = index++;
  returnn;
}