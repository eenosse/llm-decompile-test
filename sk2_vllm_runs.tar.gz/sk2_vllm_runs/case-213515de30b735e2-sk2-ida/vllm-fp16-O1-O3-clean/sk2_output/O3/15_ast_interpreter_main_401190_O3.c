main(intargc, char** argv) {
  inti;
  Node* nodes[16];
  intnum_nodes;
  Node* nodes2[16];
  intnum_nodes2;
  nodes[0] = _new_node(0);
  nodes[0]->type = 0;
  nodes[0]->value = 10.0;
  nodes[1] = _new_node(0);
  nodes[1]->type = 0;
  nodes[1]->value = 5.0;
  nodes[2] = _new_node(0);
  nodes[2]->type = 0;
  nodes[2]->value = 3.0;
  nodes[3] = _new_node_var("x");
  nodes[4] = _new_node_var("y");
  nodes[5] = _new_node(3);
  nodes[5]->type = 2;
  nodes[5]->left = nodes[2];
  nodes[5]->right = nodes[1];
  nodes[6] = _new_node(3);
  nodes[6]->type = 1;
  nodes[6]->left = nodes[5];
  nodes[6]->right = nodes[0];
  nodes[7] = _new_node(2);
  nodes[7]->type = 9;
  nodes[7]->left = _new_node_func("abs");
  nodes[8] = _new_node(0);
  nodes[8]->type = 0;
  nodes[8]->value = 20.0;
  nodes[9] = _new_node(3);
  nodes[9]->type = 5;
  nodes[9]->left = _new_node_func("sqr");
  nodes[9]->right = nodes[8];
  nodes[10] = _new_node(5);
  nodes[10]->type = 11;
  nodes[10]->left = _new_node_func("len");
  nodes[10]->right = nodes[9];
  nodes[11] = _new_node_var("z");
  nodes[12] = _new_node_str("ok");
  nodes[13] = _new_node_str("val:");
  nodes[14] = _new_node(3);
  nodes[14]->type = 11;
  nodes[14]->left = nodes[13];
  nodes[14]->right = nodes[10];
  nodes[15] = _new_node_var("msg");
  nodes[16] = _new_node_str("len");
  nodes[17] = _new_node_str("z");
  nodes[18] = _new_node(3);
  nodes[18]->type = 0;
  nodes[18]->left = nodes[17];
  nodes[18]->right = nodes[16];
  num_nodes = 16;
  _eval_nodes(nodes, num_nodes);
  _eval_nodes2(nodes, num_nodes);
  for (i = 0; i < num_nodes; i++) {
    if (nodes[i]->type < 3) {
      printf("node%d:%f\n", i, nodes[i]->value);
    }
  }
  for (i = 0; i < num_nodes; i++) {
    if (nodes[i]->type == 2) {
      free(nodes[i]->str);
    }
  }
  for (i = 0; i < num_nodes; i++) {
    free(nodes[i]);
  }
  return0;
}