ast_count(node* p, char* s) {
  inti = 0;
  intj = 0;
  intk;
  switch (p->nkind) {
  case2:
    p = p->next;
    j++;
    break;
  case3:
    k = func1(p->next, s);
    p = p->bro;
    j += k + 1;
    break;
  case4:
    k = p->nvalue;
    if (k == 0) {
      j++;
      returni + j;
    }
    k = func1(p->bro, s) + 1;
    if (k == 1) {
      returni + j + k;
    }
    k += func1(p->son, s);
    if (k == 2) {
      returni + j + k;
    }
    k += func1(p->sib, s);
    if (k == 3) {
      returni + j + k;
    }
    p = p->father;
    i += j + k;
    break;
  case5:
    k = func1(p->fst, s);
    k += func1(p->next, s);
    p = p->bro;
    j += k + 1;
    if (p == NULL) {
      returni + j;
    }
    j += k;
    break;
  case6:
    k = p->ntype;
    if (k == 0) {
      j++;
      returni + j;
    }
    k = func1(p->fst, s) + 1;
    if (k == 1) {
      returni + j + k;
    }
    k += func1(p->next, s);
    if (k == 2) {
      returni + j + k;
    }
    k += func1(p->bro, s);
    if (k == 3) {
      returni + j + k;
    }
    k += func1(p->son, s);
    if (k == 4) {
      returni + j + k;
    }
    k += func1(p->sib, s);
    if (k == 5) {
      returni + j + k;
    }
    k += func1(p->father, s);
    if (k == 6) {
      returni + j + k;
    }
    k += func1(p->sec, s);
    if (k == 7) {
      returni + j + k;
    }
    p = p->thd;
    i += j + k;
    break;
  case7:
    p = p->bro;
    j++;
    break;
    default:
      j++;
      returni + j;
  }
  returni + j;
}