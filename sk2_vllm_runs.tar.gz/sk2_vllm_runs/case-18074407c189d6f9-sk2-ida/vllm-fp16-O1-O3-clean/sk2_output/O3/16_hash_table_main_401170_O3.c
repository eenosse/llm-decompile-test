main(intargc, char** argv) {
  typedefstructnode {
    char* key;
    unsignedinthash;
    unsignedshortkeylen;
    unsignedintcount;
    doublescore;
    unsignedintid;
    structnode* next;
  }
  node;
  node** table;
  unsignedinttablelen = 0;
  unsignedinttablesize = 8;
  table = calloc(tablesize, sizeof(node*));
  if (table == NULL) {
    exit(1);
  }
  unsignedintcount = 0;
  unsignedintsum = 0;
  unsignedintn = 10;
  unsignedintmask = tablesize - 1;
  for (inti = 0; i < n; i++) {
    char* key = keys[i];
    doublescore = 1.5 + i % 5;
    unsignedinthash = hash(key, n);
    unsignedintj = 0;
    node* n = table[hash & mask];
    while (n != NULL) {
      j++;
      if (n->hash == hash && !strcmp(n->key, key)) {
        score += n->score;
        n->count++;
        n->score = score;
        break;
      }
      n = n->next;
    }
    sum += j;
    if (n == NULL) {
      sum++;
      unsignedintkeylen = strlen(key);
      node* n = calloc(1, sizeof(node) + keylen);
      if (n == NULL) {
        exit(1);
      }
      memcpy(n->key, key, keylen + 1);
      n->hash = hash;
      n->keylen = keylen;
      n->count = 1;
      n->score = score;
      n->id = i % 3;
      n->next = table[hash & mask];
      table[hash & mask] = n;
      count++;
    }
  }
  sum /= count;
  for (unsignedinti = 0; i < tablesize; i++) {
    node* n = table[i];
    unsignedintj = 0;while(n