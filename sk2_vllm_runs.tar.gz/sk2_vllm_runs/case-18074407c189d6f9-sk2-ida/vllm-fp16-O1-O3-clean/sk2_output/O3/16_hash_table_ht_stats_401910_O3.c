ht_stats(Graph* graph) {
  intV = graph->V;
  Vertex* vertex = calloc(V, sizeof(Vertex));
  if (vertex == NULL) {
    exit(1);
  }
  Vertex* vertex1 = vertex;
  inti;
  intj;
  intk = 0;
  for (i = 0; i != V; i++) {
    Node* node = graph->adj[i];
    vertex1[i].id = i;while(node