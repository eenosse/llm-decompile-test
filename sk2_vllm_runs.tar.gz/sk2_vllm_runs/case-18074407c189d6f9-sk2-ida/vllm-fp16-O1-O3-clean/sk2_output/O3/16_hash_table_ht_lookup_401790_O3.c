*ht_lookup(Hash* h, constchar* key) {
  unsignedinthash = _HashKey(key);
  intcount = 0;
  HashNode* node = h->nodes[hash & (h->size - 1)];
  if (node) {
    count = 0;
    do {
      count++;
      if (node->hash == hash && !strcmp(node->key, key)) {
        break;
      }
      node = node->next;
    } while (node);
  }
  h->collisions += count;
  returnnode;
}