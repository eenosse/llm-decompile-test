entry_new(constchar* str, int i) {
  unsignedintlen = strlen(str);
  unsignedchar* ret = calloc(1, 40 + len);
  if (ret == NULL) exit(1);
  memcpy(ret + 40, str, len + 1);
  *(unsignedint*)(ret + 4) = len;
  *(int*)(ret + 8) = i;
  returnret;
}