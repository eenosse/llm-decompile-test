ht_init(_vector* v, intsize) {
  memset(v, 0, sizeof(_vector));
  v->data = calloc(size, sizeof(double));
  if (v->data == NULL) {
    exit(1);
  }
  v->size = size;
}