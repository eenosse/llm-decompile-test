ht_dump(T* t) {
  unsignedinti;
  constchar* s;
  for (i = 0; i < t->n; i++) {
    s = t->v[i];
    if (s) {
      printf("%u", i);
      while (s) {
        printf("%s%u%u%.1f%u%08x", s + 40, *(unsignedshort*)(s + 40 + 4),
               *(unsignedint*)(s + 40 + 8), *(double*)(s + 40 + 12),
               *(unsignedchar*)(s + 40 + 20), *(unsignedint*)(s + 40 + 24));
        s = *(constchar**)s;
      }
      printf("\n");
    }
  }
}