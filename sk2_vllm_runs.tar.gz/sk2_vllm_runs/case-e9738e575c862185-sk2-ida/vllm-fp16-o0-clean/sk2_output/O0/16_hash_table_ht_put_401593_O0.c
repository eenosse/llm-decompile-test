*ht_put(Hash* hash, constchar* key, chartype, doublevalue) {
  HashNode* node = _HashFind(hash, key);
  if (node) {
    node->count++;
    node->value += value;
    returnnode;
  }
  if (hash->size >= hash->capacity * 4) _HashRehash(hash);
  intlen = strlen(key);
  inthashcode = _HashCode(key, len);
  intindex = hashcode & (hash->capacity - 1);
  node = _HashNodeNew(key, hashcode);
  node->count = 1;
  node->value = value;
  node->type = type;
  if (hash->table[index]) hash->collisions++;
  node->next = hash->table[index];
  hash->table[index] = node;
  hash->size++;
  returnnode;
}