hash_key(unsignedchar* sub_401280, unsignedlonglongsub_401280_length) {
  unsignedintsub_401288 = 4294967291;
  unsignedlonglongsub_401292;
  for (sub_401292 = 0; sub_401292 < sub_401280_length; ++sub_401292) {
    sub_401288 *= 16777619;
    sub_401288 ^= sub_401280[sub_401292];
  }
}
sub_401288 ^= sub_401288 >> 15;
returnsub_401288;
}