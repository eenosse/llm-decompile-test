ht_stats(Graph* graph) {
  unsignedinti;
  unsignedintj;
  unsignedintk;
  unsignedintmax;
  unsignedint* degrees;
  Node* node;
  degrees = calloc(graph->order, 2 * sizeof(unsignedint));
  j = 0;
  max = 0;
  if (degrees == NULL) {
    exit(1);
  }
  for (i = 0; i < graph->order; i++) {
    degrees[2 * i + 1] = i;
    node = graph->nodes[i];
    while (node != NULL) {
      degrees[2 * i]++;
      node = node->next;
    }
    if (degrees[2 * i] != 0) {
      j++;
      if (degrees[2 * i] > max) {
        max = degrees[2 * i];
      }
    }
  }
  qsort(degrees, graph->order, 2 * sizeof(unsignedint), compare);
  printf("%u%u%u%.2f%u%u%u%llu\n", graph->size, graph->order, j,
         (double)graph->size / (double)graph->order, max, graph->min,
         graph->max, graph->sum);
  for (k = 0; k < 5 && k < graph->order; k++) {
    printf("%u%u", degrees[2 * k + 1], degrees[2 * k]);
  }
  printf("\n");
  free(degrees);
}