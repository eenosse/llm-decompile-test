ht_free(_hash_table_* ht) {
  inti;
  _hash_table_node_* node;
  _hash_table_node_* next;
  for (i = 0; i < ht->size; i++) {
    node = ht->nodes[i];
    while (node != NULL) {
      next = node->next;
      free(node);
      node = next;
    }
  }
  free(ht->nodes);
  memset(ht, 0, sizeof(_hash_table_));
}