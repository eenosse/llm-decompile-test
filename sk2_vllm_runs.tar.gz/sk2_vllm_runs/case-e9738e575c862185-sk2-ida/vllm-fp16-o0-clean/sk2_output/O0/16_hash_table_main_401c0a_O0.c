main(intargc, char** argv) {
  js_tjshandle_tjsh;
  _tjs_init(&tjsh, 8);
  for (inti = 0; i < 20; i++) {
    _tjs_add(&tjsh, files[i], i % 3, 1.5 + i % 5);
  }
  tjs_build(&tjsh);
  tjs_print(&tjsh);
  js_tjsfile_t* file = tjs_get(&tjsh, "app.js");
  if (file) {
    printf("%u%.1f%u\n", file->size, file->version, file->type);
  }
  file = tjs_get(&tjsh, "nope.txt");
  printf("%d\n", file != NULL);
  intapi_users = tjs_get_index(&tjsh, "api/users");
  intnope_txt = tjs_get_index(&tjsh, "nope.txt");
  printf("%d%d\n", api_users, nope_txt);
  tjs_print(&tjsh);
  _tjs_free(&tjsh);
  return0;
}