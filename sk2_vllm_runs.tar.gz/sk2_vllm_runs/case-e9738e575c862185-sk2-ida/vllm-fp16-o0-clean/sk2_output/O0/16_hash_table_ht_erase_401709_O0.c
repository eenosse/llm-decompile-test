ht_erase(hashtable* ht, constchar* key) {
  inthash = _hashfunc(key, strlen(key));
  intindex = hash & (ht->size - 1);
  entry** p = &ht->table[index];
  entry* e;
  while (*p) {
    e = *p;
    if (e->hash == hash && !strcmp(e->key, key)) {
      *p = e->next;
      free(e);
      ht->count--;
      return1;
    }
    p = &e->next;
  }
  return0;
}