ht_grow(Hash* hash) {
  inti;
  intnewsize;
  intindex;
  Node** oldnodes;
  Node* next;
  Node** newnodes;
  newsize = 1 << hash->size;
  newnodes = calloc(newsize, sizeof(Node*));
  if (newnodes == NULL) exit(1);
  for (i = 0; i < hash->size; i++) {
    oldnodes = hash->nodes[i];while(oldnodes