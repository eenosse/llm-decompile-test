hlist_add_tail(_list_node_t_* a, _list_node_t_* b) {
  b->prev = a->prev;
  b->next = a;
  a->prev->next = b;
  a->prev = b;
}