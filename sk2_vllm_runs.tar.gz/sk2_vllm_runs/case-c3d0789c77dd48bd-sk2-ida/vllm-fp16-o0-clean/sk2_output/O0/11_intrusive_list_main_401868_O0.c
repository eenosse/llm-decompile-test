main(intargc, char** argv) {
  event_basebase;
  event_base_init(&base);
  event_base_new_worker(&base, 1, "init", 1);
  event_base_new_worker(&base, 7, "worker", 5);
  event_base_new_worker(&base, 9, "logger", 3);
  event_base_new_worker(&base, 12, "gc", 9);
  event_timer_tmt[2];
  for (unsignedi = 0; i < 2; ++i) {
    memset(&mt[i], 0, sizeof(mt[i]));
    mt[i].timeout = 1030 + i * 25;
    mt[i].cb = tmr_cb;
    snprintf(mt[i].name, 12, "tmr%u", i);
    mt[i].ev.ev_base = &mt[i].ev;
    mt[i].ev.ev_parent = &mt[i].ev;
    event_add(&mt[i].ev);
  }
  event_buf_tbuf[3];
  for (unsignedi = 0; i < 3; ++i) {
    memset(&buf[i], 0, sizeof(buf[i]));
    buf[i].id = i + 1;
    buf[i].len = (i + 1) * 8;
    memset(buf[i].data, i + 64, buf[i].len);
    buf[i].ev.ev_base = &buf[i].ev;
    buf[i].ev.ev_parent = &buf[i].ev;
    event_add(&buf[i].ev);
  }
  for (unsignedi = 0; i < 8; ++i) {
    if (event_base_got_exit(&base)) {
      break;
    }
    event_base_loop(&base, 15 + (i % 3));
  }
  event_base_free(&base);
  size_tlen = event_queue_get_len(&mt[0].ev);
  size_tlen2 = event_queue_get_len(&base.event_queue);
  printf("%u%zu%zu\n", buf[0].id, len2, len);
  while (!event_base_got_exit(&base.event_queue)) {
    event_t* ev = (event_t*)base.event_queue.ev_base;
    event_t* ev2 = (event_t*)((char*)ev - sizeof(event_t));
    event_del(ev);
    if (ev2->ev.ev_parent != &ev2->ev) {
      event_del(&ev2->ev);
    }
    free(ev2);
  }
  return0;
}