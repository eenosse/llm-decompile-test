sched_pick(structlist* list) {
  structnode* max = NULL;
  structnode* node;
  _foreach(node, list, next) {
    if (max == NULL || node->value > max->value) max = node;
  }
  returnmax;
}