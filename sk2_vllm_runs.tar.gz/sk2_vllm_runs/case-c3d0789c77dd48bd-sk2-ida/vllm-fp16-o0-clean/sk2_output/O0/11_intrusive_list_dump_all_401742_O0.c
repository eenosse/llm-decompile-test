dump_all(T* t) {
  size_tn;
  S* s;
  n = func2(&t->a);
  printf("%zu\n", n);for(s=t->a.n;s