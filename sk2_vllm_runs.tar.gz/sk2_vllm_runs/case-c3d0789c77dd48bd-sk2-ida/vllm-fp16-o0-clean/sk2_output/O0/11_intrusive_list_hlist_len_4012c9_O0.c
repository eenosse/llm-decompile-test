hlist_len(list_t* list) {
  size_ti = 0;
  node_t* node;
  for (node = list->next; node != list; node = node->next) i++;
  returni;
}
#Whatisthesourcecode ?