*task_create(SymbolTable* table, inttype, constchar* name, intvalue) {
  Symbol* symbol = calloc(1, sizeof(Symbol));
  if (symbol == NULL) exit(1);
  symbol->type = type;
  strncpy(symbol->name, name, 15);
  symbol->value = value;
  symbol->references = 1;
  symbol->next_local = &symbol->list;
  symbol->next_global = &symbol->list;
  symbol->next_local_param = &symbol->param;
  symbol->next_global_param = &symbol->param;
  _add_symbol(&table->local, &symbol->next_local);
  _add_symbol(&table->global, &symbol->next_global);
  returnsymbol;
}