sched_init(long* a) {
  a[0] = a;
  a[1] = a;
  a[2] = a + 2;
  a[3] = a + 2;
  a[4] = a + 4;
  a[5] = a + 4;
  a[6] = a + 6;
  a[7] = a + 6;
  a[8] = 1000;
  a[9] = 0;
}