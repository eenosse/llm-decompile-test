event_print(unsignedchar* p, size_tlen) {
  intret;
  printf("%zu%llu%d", len, *(unsignedlonglong*)(p + 0), *(int*)(p + 8));
  switch (*(int*)(p + 8)) {
  case0:
    ret = putchar('\n');
    break;
  case1:
    ret = printf("%u%02x%u\n", *(unsignedshort*)(p + 12),
                 *(unsignedchar*)(p + 18), *(unsignedchar*)(p + 19));
    break;
  case2:
    ret = printf("%d%d%d%d%02x\n", *(int*)(p + 12), *(int*)(p + 16),
                 *(int*)(p + 20), *(int*)(p + 24), *(unsignedchar*)(p + 32));
    break;
  case3:
    ret = printf("%u%u%.2f\n", *(unsignedshort*)(p + 12),
                 *(unsignedshort*)(p + 16), *(float*)(p + 20));
    break;
  case4:
    ret = printf("%u|%s\n", *(unsignedshort*)(p + 12), (char*)(p + 18));
    break;
    default:
      ret = *(int*)(p + 8);
  }
  returnret;
}