ring_push(ringbuffer* r, void* data) {
  void* ptr;
  r->write_count++;
  if (r->write_pos == r->size) {
    if (r->overflow_callback) {
      r->overflow_callback(r->data + r->read_pos * r->element_size,
                           r->overflow_callback_data);
    }
    r->read_pos = (r->read_pos + 1) % r->size;
    r->write_pos--;
    r->overflow_count++;
  }
  ptr = _ringbuffer_get_ptr(r, r->write_pos);
  memcpy(ptr, data, r->element_size);
  r->write_pos++;
  returnr;
}