ring_pop(ring_pop_t* p, unsignedchar* data) {
  if (p->count == 0) {
    return0;
  }
  memcpy(data, p->data + p->head * p->size, p->size);
  p->head = (p->head + 1) % p->max;
  p->count--;
  return1;
}