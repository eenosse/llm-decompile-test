arena_alloc(r_mem_t* mem, unsignedlongsize, unsignedlongalign) {
  unsignedlongoffset;
  void* ptr;
  offset = (mem->offset + align - 1) & -align;
  if (mem->offset + offset > mem->size) return0;
  ptr = mem->data + offset;
  mem->offset += size;
  if (mem->offset > mem->maxoffset) mem->maxoffset = mem->offset;
  mem->read++;
  returnptr;
}