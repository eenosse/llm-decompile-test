main(intargc, char** argv) {
  c_array* array = c_array_new(sizeof(c_array_item), 5);
  c_array* array2 = c_array_new(sizeof(int), 8);
  c_buffer* buffer = c_buffer_new(1024);
  inti = 0;
  intj = 10;
  array->compare = compare;
  array->get_key = &i;
  for (intk = 0; k <= 8; ++k) {
    c_array_itemitem = {0};
    item.key = 5000 + k * 17;
    intl = k % 4;
    if (l == 2) {
      item.type = 3;
      item.size = 50 + k * 16;
      item.value = 1.0f + (k % 3) * 0.25f;
    }
    elseif(l >= 3) {
      item.type = 4;
      snprintf(item.string, 24, "chunk-%02u", k);
      item.size = strlen(item.string);
    }
    elseif(l >= 1) {
      item.type = 2;
      item.size = k * 30;
      item.value = 200 - k * 12;
      item.i = k;
      item.j = -k;
      item.k = 1 << (k % 3);
    }
    else {
      item.type = 1;
      item.size = k + 64;
      item.i = k & 7;
      item.j = k & 1;
    }
  }
  c_array_add(array, &item);
  intm = i;
  size_tn = array->size;
  size_tcapacity = c_array_capacity(array);
  printf("%zu%llu%llu%u\n", capacity, n, m, m);
  c_array_sort(array, compare_item, NULL);
  c_array_itemitem;
  while (c_array_next(array, &item)) {
    printf("%d%llu\n", item.type, item.key);
  }
  for (intk = 0; k <= 5; ++k) {
    intn = k * k;
    c_array_add(array2, &n);
  }
  c_array_sort(array2, compare_int, &j);
  intn;
  while (c_array_next(array2, &n)) {
    printf("%d", n);
  }
  putchar(10);
  unsignedshort* us = c_buffer_alloc(buffer, 4, 4);
  unsignedshort* ui = c_buffer_alloc(buffer, 20, 8);
  unsignedshort* ul = c_buffer_alloc(buffer, 8, 8);
  char* s = c_buffer_alloc(buffer, 32, 1);
  *us = 27;
  us[3] = 1;
  *((int*)ui) = 11;
  *((int*)(ui + 4)) = 22;
  ui[16] = 4;
  *ul = 1920;
  ul[1] = 1080;
  *((int*)(ul + 1)) = 1073741824;
  snprintf(s, 32, "arenastring");
  printf("%zu%zu%u%u%d%d%u%u|%s\n", buffer->offset, buffer->size_max,
         buffer->size, *us, *ui, *(ui + 4), *ul, ul[1], s);
  c_array_free(array);
  c_array_free(array2);
  c_buffer_free(buffer);
  return0;
}