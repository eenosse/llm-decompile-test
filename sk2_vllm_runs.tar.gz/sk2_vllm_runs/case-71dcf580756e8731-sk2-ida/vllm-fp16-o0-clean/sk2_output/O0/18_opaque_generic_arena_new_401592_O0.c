*arena_new(intsize) {
  string* s;
  s = calloc(1, sizeof(string));
  if (s == NULL) exit(1);
  s->data = calloc(1, size);
  if (s->data == NULL) exit(1);
  s->size = size;
  returns;
}