ring_foreach(_vector_pointer_t_this, void (*_func)(void*, unsignedlong, void*),
             void* arg) {
  unsignedlongi;
  void* item;
  unsignedlonglen;
  len = this->size;
  for (i = 0; i < len; i++) {
    item = _vector_pointer_t_get(this, i);
    _func(item, i, arg);
  }
}