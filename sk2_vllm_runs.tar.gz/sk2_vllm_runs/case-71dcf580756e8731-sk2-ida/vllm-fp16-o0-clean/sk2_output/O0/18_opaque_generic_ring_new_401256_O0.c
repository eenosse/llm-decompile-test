ring_new(intsize, intlength) {
  Vector* v = calloc(1, sizeof(Vector));
  if (v == NULL) exit(1);
  v->data = calloc(length, size);
  if (v->data == NULL) exit(1);
  v->size = size;
  v->length = length;
  returnv;
}