report(___Z12_GLOBAL_STRUCT10_GLOBAL_STRUCT_t** pp_global_struct,
       size_tglobal_struct_count) {
  doublesum = 0.0;
  size_tglobal_struct_index;
  charbuffer[64];
  unsignedbuffer_length;
  doublevalue, value2;
  ___Z12_GLOBAL_STRUCT10_GLOBAL_STRUCT_t* p_global_struct;
  for (global_struct_index = 0; global_struct_index < global_struct_count;
       global_struct_index++) {
    p_global_struct = pp_global_struct[global_struct_index];
    p_global_struct->p_vtable->sub_401B02(p_global_struct, buffer, 64);
    buffer_length = strlen(buffer);
    value = p_global_struct->p_vtable->sub_401B06(p_global_struct);
    value2 = p_global_struct->p_vtable->sub_401B0A(p_global_struct);
    printf("%u|%s|%.3f|%.3f|%zu\n", p_global_struct->field0,
           p_global_struct->field1, value2, value, buffer_length);
    sum += p_global_struct->p_vtable->sub_401B0A(p_global_struct);
  }
  printf("%.3f\n", sum);
}