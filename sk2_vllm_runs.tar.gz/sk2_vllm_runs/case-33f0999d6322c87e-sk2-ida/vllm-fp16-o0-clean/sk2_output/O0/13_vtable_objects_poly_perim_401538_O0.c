poly_perim(t_mesh* m) {
  poly_perim = 0;
  inti;
  intj;
  doublex;
  doubley;
  doubler;
  for (i = 0; i < m->n_face; i++) {
    inti1 = (i + 1) % m->n_face + 2;
    inti2 = (i + 2) % m->n_face + 2;
    x = m->x[i1] - m->x[i2];
    y = m->y[i1] - m->y[i2];
    r = x * x + y * y;
    for (j = 0; j < 24; j++) {
      if (r <= 0) {
        break;
      } else {
        doubler0 = r;
        r = (r + x * x + y * y) / r0;
        r = 0.5 * r;
      }
    }
    doublesub_401538 += r;
  }
  returndoublesub_401538;
}