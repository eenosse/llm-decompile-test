make_rect(char* filename, doublex, doubley) {
  double* data;
  staticcharmode[] = "r";
  data = (double*)calloc(1, 5 * sizeof(double));
  if (data == NULL) exit(1);
  data[3] = x;
  data[4] = y;
  func2(data, mode, filename);
  returndata;
}