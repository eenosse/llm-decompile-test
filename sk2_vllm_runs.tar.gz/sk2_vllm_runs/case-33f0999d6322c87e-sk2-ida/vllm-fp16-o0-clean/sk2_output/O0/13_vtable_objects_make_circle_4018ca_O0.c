make_circle(constchar* str, doubleval) {
  double* ret;
  ret = calloc(1, sizeof(double) * 4);
  if (ret == NULL) exit(1);
  ret[3] = val;
  returnfunc2(ret, &func3, str);
}