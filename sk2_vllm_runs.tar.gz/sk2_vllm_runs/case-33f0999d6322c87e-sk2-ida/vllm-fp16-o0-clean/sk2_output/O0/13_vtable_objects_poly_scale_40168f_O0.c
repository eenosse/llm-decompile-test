poly_scale(double* x, doubley) {
  unsignedinti;
  for (i = 0; i < *(unsignedint*)x; i++) {
    x[2 + 2 * i] *= y;
    x[2 + 2 * i + 1] *= y;
  }
}