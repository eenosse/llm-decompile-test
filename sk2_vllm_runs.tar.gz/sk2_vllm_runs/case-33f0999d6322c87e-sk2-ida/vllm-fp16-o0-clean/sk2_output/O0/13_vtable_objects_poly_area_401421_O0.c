poly_area(double* x) {
  inti;
  doublesum;
  sum = 0.0;
  for (i = 0; i < x[3]; i++) {
    sum += (x[2 + 2 * i] * x[1 + 2 * ((i + 1) % x[3])] -
            x[1 + 2 * i] * x[2 + 2 * ((i + 1) % x[3])]);
  }
  if (sum < 0.0) {
    sum = -sum / 2.0;
  } else {
    sum = sum / 2.0;
  }
  returnsum;
}