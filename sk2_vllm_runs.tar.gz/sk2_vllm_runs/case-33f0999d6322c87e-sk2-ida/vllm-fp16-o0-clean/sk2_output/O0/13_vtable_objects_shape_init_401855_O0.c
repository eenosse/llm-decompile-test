shape_init(struct_s* s, unsignedlongid, constchar* name) {
  s->id = id;
  s->seq = seq++;
  memset(s->name, 0, 12);
  strncpy(s->name, name, 11);
}