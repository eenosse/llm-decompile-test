make_rrect(constchar* name, doublex, doubley, doublez) {
  double* params;
  staticdoubletranslation[6] = {0, 0, 0, 1, 0, 0};
  params = (double*)calloc(1, 6 * sizeof(double));
  if (params == NULL) exit(1);
  params[3] = x;
  params[4] = y;
  params[5] = z;
  return_ch_create_affine(params, translation, name);
}