make_poly(char** argv, intargc, constchar* str) {
  inti;
  intj;
  char** argv2;
  staticchar* argv3[] = {"0", "1", "2", "3", "4", "5",
                         "6", "7", "8", "9", NULL};
  j = argc;
  argv2 = calloc(1, sizeof(char*) * 20);
  if (argv2 == NULL) exit(1);
  if (j > 8) j = 8;
  argv2[6] = (char*)j;
  for (i = 0; i < j; i++) {
    argv2[i * 2 + 8] = argv[i * 2];
    argv2[i * 2 + 9] = argv[i * 2 + 1];
  }
  func2(argv2, argv3, str);
}