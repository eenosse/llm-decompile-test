main(intargc, char* argv[]) {
  inti;
  Shape* shapes[5];
  shapes[0] = newCircle("c1", 2.5);
  shapes[1] = newRectangle("r1", 3.0, 4.0);
  shapes[2] = newPolygon("tri", 3, (float[3]){0.0, 0.0, 0.0});
  shapes[3] = newPolygon("quad", 4, (float[4]){0.0, 0.0, 0.0, 0.0});
  shapes[4] = newRoundedRectangle("rr1", 6.0, 4.0, 1.0);
  printShapes(shapes, 5);
  for (i = 0; i < 5; i++) {
    shapes[i]->scale(shapes[i], 1.5);
  }
  printShapes(shapes, 5);
  for (i = 0; i < 5; i++) {
    if (shapes[i]->vtbl == &circleVtbl) {
      Circle* c = (Circle*)shapes[i];
      printf("%.2f%.2f%.2f%u\n", c->x, c->y, c->r, c->color);
    }
    elseif(shapes[i]->vtbl == &polygonVtbl) {
      Polygon* p = (Polygon*)shapes[i];
      printf("%s%.2f%.2f%.2f%.2f\n", p->name, p->y, p->r,
             p->points[p->color - 1].x, p->points[p->color - 1].y);
    }
  }
  for (i = 0; i < 5; i++) {
    shapes[i]->destroy(shapes[i]);
  }
  return0;
}