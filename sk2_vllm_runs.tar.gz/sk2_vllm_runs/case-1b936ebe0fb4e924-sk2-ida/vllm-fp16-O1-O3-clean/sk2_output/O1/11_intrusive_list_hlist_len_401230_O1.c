hlist_len(Node* head) {
  inti;
  Node* p;
  i = 0;
  p = head->next;
  while (p != head) {
    i++;
    p = p->next;
  }
  returni;
}