task_create(structSymbolTable* table, inttype, constchar* name, intvalue) {
  structSymbol* symbol = calloc(1, sizeof(structSymbol));
  if (symbol == NULL) exit(1);
  symbol->type = type;
  strncpy(symbol->name, name, 15);
  symbol->value = value;
  symbol->references = 1;
  symbol->nextSymbol = table->symbols;
  symbol->prevSymbol = &table->symbols;
  table->symbols->nextSymbol = &symbol->nextSymbol;
  table->symbols = symbol->nextSymbol;
  symbol->nextSymbolInScope = table->symbolsInScope;
  symbol->prevSymbolInScope = &table->symbolsInScope;
  table->symbolsInScope->nextSymbolInScope = &symbol->nextSymbolInScope;
  table->symbolsInScope = symbol->nextSymbolInScope;
  returnsymbol;
}