hlist_del(_list_node_t* node) {
  _list_node_t* next = node->next;
  next->prev = node->next;
  node->prev->next = node->next;
  node->next = node;
  node->prev = node;
}