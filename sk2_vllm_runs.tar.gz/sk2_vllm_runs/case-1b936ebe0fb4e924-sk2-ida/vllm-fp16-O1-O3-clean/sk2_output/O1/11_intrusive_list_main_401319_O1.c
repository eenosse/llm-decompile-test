main(intargc, char** argv) {
  typedefstructnode {
    structnode* next;
    structnode* prev;
    unsignedintdata;
    unsignedintsize;
    unsignedintref;
    unsignedintid;
    char* buf;
  }
  node;
  typedefstructworker {
    structworker* next;
    structworker* prev;
    unsignedintdata;
    unsignedintsize;
    unsignedintref;
    unsignedintid;
    char* buf;
  }
  worker;
  typedefstructlogger {
    structlogger* next;
    structworker* prev;
    unsignedintdata;
    unsignedintsize;
    unsignedintref;
    unsignedintid;
    char* buf;
  }
  logger;
  typedefstructgc {
    structgc* next;
    structworker* prev;
    unsignedintdata;
    unsignedintsize;
    unsignedintref;
    unsignedintid;
    char* buf;
  }
  gc;
  typedefstructinit {
    structinit* next;
    structworker* prev;
    unsignedintdata;
    unsignedintsize;
    unsignedintref;
    unsignedintid;
    char* buf;
  }
  init;
  nodeinit;
  workerworker;
  loggerlogger;
  gcgc;
  initinit;
  unsignedinti = 1000;
  unsignedintj = 0;
  _init(&init, 1, "init", 1);
  _init(&init, 7, "worker", 5);
  _init(&init, 9, "logger", 3);
  _init(&init, 12, "gc", 9);
  workerworker.next = NULL;
  workerworker.prev = NULL;
  workerworker.ref = 0;
  workerworker.id = 0;
  workerworker.size = 1030;
  workerworker.buf = _malloc(workerworker.size);
  workerworker.prev = &worker;
  workerworker.next = &worker;
  worker.next = NULL;
  worker.prev = NULL;
  worker.ref = 0;
  worker.id = 0;
  worker.size = 1055;
  worker.buf = _malloc(worker.size);
  worker.prev = &logger;
  worker.next = &logger;
  logger.next = NULL;
  logger.prev = NULL;
  logger.ref = 0;
  logger.id = 0;
  logger.size = 1055;
  logger.buf = _malloc(logger.size);
  logger.prev = &gc;
  logger.next = &gc;
  gc.next = NULL;
  gc.prev = NULL;
  gc.ref = 0;
  gc.id = 0;
  gc.size = 1055;
  gc.buf = _malloc(gc.size);
  gc.prev = &init;
  gc.next = &init;
  for (unsignedintk = 1; k != 4; ++k) {
    node* n = (node*)_malloc(sizeof(node));
    n->next = NULL;
    n->prev = NULL;
    n->ref = 0;
    n->id = 0;
    n->size = k * 8;
    n->data = k;
    memset(n->buf, k + 63, n->size);
    n->prev = worker.next;
    n->next = &worker;
    worker.next = n;
#Whatisthesourcecode ? #
  }
}