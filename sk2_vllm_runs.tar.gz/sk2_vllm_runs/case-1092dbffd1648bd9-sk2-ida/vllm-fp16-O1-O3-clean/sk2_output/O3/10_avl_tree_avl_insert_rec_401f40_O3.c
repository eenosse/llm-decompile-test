*avl_insert_rec(Tree* tree, Node node, int key, int* value) {
  if (node == NULL) {
    tree->size++;
    temp = (Node)calloc(1, sizeof(NodeStruct));
    if (temp == NULL) {
      exit(1);
    }
    temp->color = 1;
    temp->key = key;
    for (inti = 0; i < 3; i++) {
      temp->value[i] = value[i];
    }
    returntemp;
  }
  if (node->key == key) {
    for (inti = 0; i < 3; i++) {
      node->value[i] = value[i];
    }
    returnnode;
  }
  if (key < node->key) {
    node->child[0] = func1(tree, node->child[0], key, value);
  } else {
    node->child[1] = func1(tree, node->child[1], key, value);
  }
  tree->size++;
  returnfunc2(tree, node);
}
#Whatisthesourcecode ?