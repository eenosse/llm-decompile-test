avl_print(node* root, intlevel) {
  inti;
  if (root == NULL) return;
  for (i = 0; i < level; i++) {
    func1(root->right, level + 1);
    root = root->left;
  }
  printf("");
}