*avl_erase_rec(Tree* tree, Node* node, intkey) {
  intnewkey;
  Node* temp;
  Node* temp2;
  inttempkey;
  if (node == NULL) returnNULL;
  if (node->key == key) {
    temp = node->right;
    if (node->left == NULL) {
      free(node);
      tree->size--;
      returntemp;
    }
    temp2 = node->right;
    if (temp2 == NULL) {
      temp = node->left;
      free(node);
      tree->size--;
      returntemp;
    }while(temp2->right