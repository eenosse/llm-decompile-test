truthy(int* args) {
  intret;
  switch (args[0]) {
  case0:
    ret = (args[1] != 0.0);
    break;
  case1:
    ret = args[2];
    break;
  case2:
    ret = (args[2] != 0);
    break;
    default:
      ret = 0;
  }
  returnret;
}