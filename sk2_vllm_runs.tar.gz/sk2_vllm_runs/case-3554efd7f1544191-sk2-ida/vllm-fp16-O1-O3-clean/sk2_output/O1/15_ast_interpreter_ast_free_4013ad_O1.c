ast_free(node* n) {
  inti;
  switch (n->type) {
  caseN_STRING:
    if (n->ref == 2) free(n->value);
    break;
  caseN_FUNC:
    func1(n->value);
    break;
  caseN_FUNC_CALL:
    func1(n->value);
    func1(n->next);
    break;
  caseN_ARRAY:
    for (i = 0; i < n->array_size; i++) func1(n->array[i]);
    break;
  caseN_ARRAY_ELEM:
    func1(n->array_elem);
    func1(n->value);
    if (n->next) func1(n->next);
    break;
  caseN_OPERATOR:
    func1(n->next);
    break;
    default:
      break;
  }
  free(n);
}