node_new(intvar1) {
  int* ret = calloc(1, sizeof(int) * 20);
  if (ret == NULL) exit(1);
  ret[0] = var1;
  ret[1] = id++;
  returnret;
}