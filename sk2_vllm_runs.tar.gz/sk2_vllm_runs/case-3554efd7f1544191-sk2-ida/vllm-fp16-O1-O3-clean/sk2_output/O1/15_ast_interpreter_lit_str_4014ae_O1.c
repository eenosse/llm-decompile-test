lit_str(constchar* str) {
  AST* ast = ast_new(AST_STRING);
  ast->type = TYPE_STRING;
  ast->string.value = strdup(str);
  ast->string.length = strlen(str);
  returnast;
}