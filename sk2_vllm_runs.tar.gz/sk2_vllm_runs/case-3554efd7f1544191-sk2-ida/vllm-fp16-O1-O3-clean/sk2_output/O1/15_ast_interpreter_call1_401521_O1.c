call1(constchar* name, size_tsize) {
  node* n = __create_node_struct(sizeof(node));
  strncpy(n->name, name, 15);
  n->size = size;
  n->is_free = true;
  returnn;
}