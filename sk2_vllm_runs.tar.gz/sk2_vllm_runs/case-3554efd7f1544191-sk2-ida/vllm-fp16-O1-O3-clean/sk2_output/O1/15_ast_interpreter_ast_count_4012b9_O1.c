ast_count(Node* p) {
  intn;
  intn1;
  intn2;
  intn3;
  inti;
  switch (p->nodetype) {
  case2:
    n = 1 + func1(p->ptr1);
    break;
  case3:
    n1 = func1(p->ptr1);
    n2 = func1(p->ptr2);
    n = 1 + n1 + n2;
    break;
  case4:
    n3 = p->nsubnodes;
    n = 1;
    for (i = 0; i < n3; i++) {
      n += func1(p->subnodes[i]);
    }
    break;
  case5:
    n1 = func1(p->ptr3);
    n2 = func1(p->ptr1);
    n = 1 + n1 + n2;
    if (p->ptr2) {
      n += func1(p->ptr2);
    }
    break;
  case6:
    n3 = p->nsubnodes3;
    n = 1;
    for (i = 0; i < n3; i++) {
      n += func1(p->subnodes3[i]);
    }
    break;
  case7:
    n = 1 + func1(p->ptr2);
    break;
    default:
      n = 1;
      break;
  }
  returnn;
}