conn_dump(int* a) {
  intn = a[7];
  inti;
  for (i = 0; i < n; i++) {
    printf("%d", a[11 + i]);
  }
  printf("\n");
}