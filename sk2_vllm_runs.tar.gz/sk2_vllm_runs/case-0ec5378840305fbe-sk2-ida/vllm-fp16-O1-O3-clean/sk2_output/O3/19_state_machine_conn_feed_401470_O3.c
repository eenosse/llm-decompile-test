conn_feed(int* reg, intid) {
  reg[11 + id]++;
  if (reg[7] == mem[id * 168 + 24] && func[id * 168 + 24] != NULL) {
    reg[10]++;
    printf("Error:Subroutine%dcalledrecursively\n", id);
    return;
  }
  if (func[id * 168 + 24] != NULL) {
    func[id * 168 + 24](reg, id, reg[7]);
  }
  reg[9]++;
  inttemp = mem[id * 168 + 24];
  inttemp2 = reg[7];
  reg[7] = temp;
  reg[8] = temp2;
  printf("Subroutine%dreturnedfrom%d\n", id, temp2);
}