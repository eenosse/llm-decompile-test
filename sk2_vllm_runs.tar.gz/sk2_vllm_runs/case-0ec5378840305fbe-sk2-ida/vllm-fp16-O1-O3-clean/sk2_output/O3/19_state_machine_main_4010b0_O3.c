main(intargc, char** argv) {
  inta[10] = {1, 0, 2, 0, 3, 0, 4, 0, 5, 0};
  intb[10] = {1, 2, 3, 4, 5, 0, 0, 0, 0, 0};
  intc[10] = {1, 2, 3, 4, 5, 0, 0, 0, 0, 0};
  inti;
  for (i = 0; i < 10; i++) {
    add(a, b[i]);
  }
  print(a);
  for (i = 0; i < 10; i++) {
    add(c, b[i]);
  }
  print(c);
  intcount = 0;
  for (i = 0; i < 10; i++) {
    if (b[i] != 0) {
      count++;
    }
  }
  printf("Numberofnon-zeroelements:%d\n", count);
  return0;
}