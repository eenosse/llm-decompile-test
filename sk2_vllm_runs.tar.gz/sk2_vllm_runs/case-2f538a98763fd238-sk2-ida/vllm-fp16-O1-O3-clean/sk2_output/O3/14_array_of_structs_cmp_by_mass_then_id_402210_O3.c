cmp_by_mass_then_id(float* a, float* b) {
  floatx = a[6];
  floaty = b[6];
  intflag = 1;
  if (y > x) {
    flag = -1;
    if (x > y) {
      returnflag;
    }
  }
  intxl = (int)a[8];
  intyl = (int)b[8];
  if (xl < yl) {
    return -1;
  }
  if (xl > yl) {
    return1;
  }
  return0;
}