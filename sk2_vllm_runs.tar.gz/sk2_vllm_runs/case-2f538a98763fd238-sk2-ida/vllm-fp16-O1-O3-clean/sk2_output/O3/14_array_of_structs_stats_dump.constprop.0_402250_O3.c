stats_dump.constprop .0(int* param1) {
  inteax = *(int * 1 + 0x14);
  printf("sub_402250%d\n", eax);
  returneax;
}