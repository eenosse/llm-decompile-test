aos_dump.constprop .0(char* a0) {
  inti;
  for (i = 0; i < 100; i++) {
    printf("%c", a0[i]);
  }
}