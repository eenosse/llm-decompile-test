bst_inorder_recursive(node* root, intlevel) {
  if (root != NULL) {
    func1(root->right, level + 1);
    printf("%d%s%u%u%u\n", level, root->name, root->id, root->age,
           root->salary);
    func1(root->left, level + 1);
  }
}