bst_insert(_tree_t_* tree, constchar* key, intvalue) {
  _node_t_** node = tree->root;
  _node_t_* parent = NULL;
  while (*node) {
    parent = *node;
    tree->nodes_visited++;
    intcmp = strcmp(key, parent->key);
    if (cmp == 0) {
      parent->value++;
      return;
    }
    elseif(cmp < 0) { node = &parent->left; }
    else {
      node = &parent->right;
    }
  }
  _node_t_* new_node = _func2(key, value);
  new_node->left = parent;
  *node = new_node;
  tree->nodes_inserted++;
  _node_t_* tmp = parent;
  while (tmp) {
    tmp->height++;
    tmp = tmp->left;
  }
}