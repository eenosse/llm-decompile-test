main(intargc, char** argv) {
  inti;
  TrieNode_troot;
  memset(&root, 0, sizeof(root));
  constchar* words[] = {
      "the",   "quick", "brown", "fox",   "jumps", "over",
      "the",   "lazy",  "dog",   "the",   "lazy",  "dog",
      "jumps", "over",  "the",   "quick", "brown",
  };
  for (i = 0; i < 15; i++) {
    TrieNode_insert(&root, words[i], i);
  }
  TrieNode_print(root.child, 0);
  TrieNode_print_all(root.child);
  TrieNode_print_all_words(root.child);
  printf("%s%zu%d%zu\n", root.child, root.count,
         TrieNode_count_words(root.child), root.word_count);
  TrieNode_t* node = TrieNode_find(&root, "fox");
  if (node) {
    constchar* word = TrieNode_get_word(node);
    constchar* word_str = word ? word : "-";
    constchar* word_str_2 = node->word ? node->word : "-";
    printf("%u%s%s\n", node->index, word_str_2, word_str);
  }
  constchar* word_str_3 = TrieNode_get_all_words(root.child);
  while (word_str_3) {
    printf("%s", word_str_3);
    word_str_3 = TrieNode_get_word(word_str_3);
  }
  putchar('\n');
  TrieNode_free(root.child);
  return0;
}