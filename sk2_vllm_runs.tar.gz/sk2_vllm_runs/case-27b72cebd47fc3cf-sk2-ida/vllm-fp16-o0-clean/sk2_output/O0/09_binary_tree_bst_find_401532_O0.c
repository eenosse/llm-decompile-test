bst_find(bst_t* bst, char* key) {
  char* node = bst->root;
  char* next;
  intcmp;while(node