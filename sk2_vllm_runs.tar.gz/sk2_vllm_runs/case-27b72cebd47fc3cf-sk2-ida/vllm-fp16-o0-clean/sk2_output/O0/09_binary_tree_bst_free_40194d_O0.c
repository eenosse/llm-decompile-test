bst_free(Node* node) {
  if (node) {
    func1(node->left);
    func1(node->right);
    free(node);
  }
}