bst_levelorder(node* n) {
  inti = 0;
  intj = 0;
  charbuf[512];
  token* t;
  if (n->tokens) {
    func2(buf, n->tokens);
  }
  while (!func3(buf)) {
    t = func4(buf);
    printf("%s%u", t->text, t->type);
    if (t->next) {
      func2(buf, t->next);
    }
    if (t->child) {
      func2(buf, t->child);
    }
  }
  printf("\n");
}