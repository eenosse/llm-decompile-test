stack_push(unsignedint* p, unsignedlonglongx) {
  inti = p[128];
  if (i < 64) {
    p[i++] = x;
    p[128] = i;
  }
}