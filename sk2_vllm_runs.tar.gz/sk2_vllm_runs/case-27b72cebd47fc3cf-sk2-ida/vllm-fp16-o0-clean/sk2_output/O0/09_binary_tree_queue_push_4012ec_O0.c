queue_push(int* arr, longlongval) {
  inti = arr[142];
  if (i < 64) {
    arr[i++] = val;
    returni;
  }
}