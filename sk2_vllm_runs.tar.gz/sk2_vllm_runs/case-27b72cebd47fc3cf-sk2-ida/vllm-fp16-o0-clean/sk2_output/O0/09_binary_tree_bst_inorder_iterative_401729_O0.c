bst_inorder_iterative(T401728* p) {
  wchar_tbuf[512];
  T0* l_5 = p->f0;
  intl_6 = 0;
  while (l_5 || !__builtin_iswblank(buf)) {
    while (l_5) {
      __builtin_wcscat(buf, l_5);
      l_5 = l_5->f10;
    }
    l_5 = __builtin_alloca(buf);
    printf("%s", l_5->f1);
    l_5 = l_5->f11;
  }
  putchar('\n');
}