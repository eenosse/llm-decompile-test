bst_node_new(constchar* name, inttype) {
  struct_t* s = calloc(1, sizeof(struct_t));
  if (s == NULL) {
    exit(1);
  }
  strncpy(s->name, name, 23);
  s->is_struct = 1;
  s->type = type;
  s->is_defined = 1;
  returns;
}