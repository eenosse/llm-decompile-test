queue_pop(void** _data) {
  int* data = (int*)_data;
  if (data[128] >= data[129]) return0;
  int_index = data[128];
  data[128]++;
  returndata[_index];
}