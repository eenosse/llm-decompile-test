bst_height(Node* node) {
  if (node == NULL) {
    return0;
  }
  intleft = func1(node->left);
  intright = func1(node->right);
  intmax = left > right ? left : right;
  returnmax + 1;
}