ast_count(node* tree, char* name) {
  intcount = 0;
  switch (tree->token) {
  caseIF:
    count++;
    count += func1(tree->ptr1, name);
    tree = tree->ptr2;
    break;
  caseWHILE : {
    inttemp = func1(tree->ptr1, name);
    count++;
    count += temp;
    tree = tree->ptr2;
    break;
  }
  caseFOR : {
    intnum = tree->num;
    if (num == 0) {
      count++;
      returncount;
    }
    node** temp1 = tree->temp1;
    count++;
    inti;
    for (i = 0; i < num; i++) {
      count += func1(temp1[i], name);
    }
    returncount;
  }
  caseIFELSE : {
    inttemp = func1(tree->ptr1, name);
    inttemp1 = func1(tree->ptr2, name);
    count++;
    count += temp;
    count += temp1;
    if (tree->ptr2) {
      count += func1(tree->ptr2, name);
    }
    returncount;
  }
  casePRINT:
    count++;
    tree = tree->ptr2;
    break;
    default:
      count++;
      returncount;
  }
  returncount;
}