node_new(intvar1) {
  int* p;
  p = calloc(1, 80);
  if (p == NULL) exit(1);
  p[0] = var1;
  p[1] = count;
  count++;
  returnp;
}