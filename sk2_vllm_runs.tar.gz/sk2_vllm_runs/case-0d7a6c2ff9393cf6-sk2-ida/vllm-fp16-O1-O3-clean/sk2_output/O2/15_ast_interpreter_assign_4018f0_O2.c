assign(constchar* key, void* value) {
  node* n = __create_node_instance(NODE);
  strncpy(n->key, key, 15);
  n->value = value;
  returnn;
}