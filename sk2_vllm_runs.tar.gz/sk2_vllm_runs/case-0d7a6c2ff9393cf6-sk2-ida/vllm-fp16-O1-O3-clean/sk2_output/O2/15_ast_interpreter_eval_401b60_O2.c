eval(type1* out, type1* in, type2* env) {
  out->type++;
  switch (in->kind) {
  case0:
    *out = *in;
    returnout;
  case1 : {
    type1* tmp = func2(env, in->name);
    if (tmp) {
      *out = *tmp;
      returnout;
    }
  } break;
  case2 : {
    type1left = func1(in->left, env);
    type1right = func1(in->right, env);
    switch (in->kind) {
    case0:
      out->kind = 0;
      out->value = left.value + right.value;
      returnout;
    case1:
      out->kind = 0;
      out->value = left.value - right.value;
      returnout;
    case2:
      out->kind = 0;
      out->value = left.value * right.value;
      returnout;
    case3:
      out->kind = 0;
      out->value = 0.0;
      if (right.value != 0.0) out->value = left.value / right.value;
      returnout;
    case4:
      out->kind = 1;
      out->number = left.#Whatisthesourcecode
          ? eval(type1 * out, type1 * in, type2 * env) {
        out->type++;
        switch (in->kind) {
        case0:
          *out = *in;
          returnout;
        case1 : {
          type1* tmp = func2(env, in->name);
          if (tmp) {
            *out = *tmp;
            returnout;
          }
        } break;
        case2 : {
          type1left = func1(in->left, env);
          type1right = func1(in->right, env);
          switch (in->kind) {
          case0:
            out->kind = 0;
            out->value = left.value + right.value;
            returnout;
          case1:
            out->kind = 0;
            out->value = left.value - right.value;
            returnout;
          case2:
            out->kind = 0;
            out->value = left.value * right.value;
            returnout;
          case3:
            out->kind = 0;
            out->value = 0.0;
            if (right.value != 0.0) out->value = left.value / right.value;
            returnout;
          case4:
            out->kind = 1;
            out->number = left.#Whatisthesourcecode
                ? eval(type1 * out, type1 * in, type2 * env) {
              out->type++;
              switch (in->kind) {
              case0:
                *out = *in;
                returnout;
              case1 : {
                type1* tmp = func2(env, in->name);
                if (tmp) {
                  *out = *tmp;
                  returnout;
                }
              } break;
              case2 : {
                type1left = func1(in->left, env);
                type1right = func1(in->right, env);
                switch (in->kind) {
                case0:
                  out->kind = 0;
                  out->value = left.value + right.value;
                  returnout;
                case1:
                  out->kind = 0;
                  out->value = left.value - right.value;
                  returnout;
                case2:
                  out->kind = 0;
                  out->value = left.value * right.value;
                  returnout;
                case3:
                  out->kind = 0;
                  out->value = 0.0;
                  if (right.value != 0.0) out->value = left.value / right.value;
                  returnout;
                case4:
                  out->kind = 1;
                  out->number = left.#Whatisthesourcecode
                      ? eval(type1 * out, type1 * in, type2 * env) {
                    out->type++;
                    switch (in->kind) {
                    case0:
                      *out = *in;
                      returnout;
                    case1 : {
                      type1* tmp = func2(env, in->name);
                      if (tmp) {
                        *out = *tmp;
                        returnout;
                      }
                    } break;
                    case2 : {
                      type1left = func1(in->left, env);
                      type1right = func1(in->right, env);
                      switch (in->kind) {
                      case0:
                        out->kind = 0;
                        out->value = left.value + right.value;
                        returnout;
                      case1:
                        out->kind = 0;
                        out->value = left.value - right.value;
                        returnout;
                      case2:
                        out->kind = 0;
                        out->value = left.value * right.value;
                        returnout;
                      case3:
                        out->kind = 0;
                        out->value = 0.0;if(right.value!=