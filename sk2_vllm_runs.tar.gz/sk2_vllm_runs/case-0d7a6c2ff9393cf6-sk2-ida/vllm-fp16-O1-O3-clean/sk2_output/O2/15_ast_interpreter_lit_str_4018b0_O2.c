*lit_str(char* value) {
  __node* node = __create_node(STRING);
  node->value = strdup(value);
  node->length = strlen(value);
  returnnode;
}