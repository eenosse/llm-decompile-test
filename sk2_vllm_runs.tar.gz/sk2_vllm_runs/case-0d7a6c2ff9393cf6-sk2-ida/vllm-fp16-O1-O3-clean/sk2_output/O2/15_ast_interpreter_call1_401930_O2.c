call1(char* str, void* next) {
  void* ptr;
  ptr = _new_object(4);
  strncpy(((char*)ptr) + 8, str, 15);
  *((void**)(ptr + 56)) = next;
  *((char*)(ptr + 56) + 1) = 1;
  returnptr;
}