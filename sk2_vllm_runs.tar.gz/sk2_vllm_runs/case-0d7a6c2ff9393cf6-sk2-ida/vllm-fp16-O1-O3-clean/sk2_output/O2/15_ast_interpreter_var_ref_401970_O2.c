var_ref(constchar* s) {
  char* p = __malloc(1);
  strncpy(p + 8, s, 15);
  returnp;
}