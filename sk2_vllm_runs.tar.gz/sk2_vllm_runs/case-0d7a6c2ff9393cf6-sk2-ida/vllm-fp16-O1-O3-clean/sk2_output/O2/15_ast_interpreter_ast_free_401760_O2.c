ast_free(AST* ast, FILE* f) {
  switch (ast->type) {
  caseAST_VAR:
    if (ast->var_type == 2) {
      free(ast->left);
    }
    break;
  caseAST_FUNC:
    func1(ast->left, f);
    free(ast);
    break;
  caseAST_FUNC_CALL:
    func1(ast->left, f);
    func1(ast->right, f);
    free(ast);
    break;
  caseAST_ARRAY:
    for (unsignedchari = 0; i < ast->array_size; i++) {
      func1(ast->array[i], f);
    }
    break;
  caseAST_IF:
    func1(ast->cond, f);
    func1(ast->left, f);
    if (ast->right) {
      func1(ast->right, f);
    }
    break;
  caseAST_WHILE:
    for (unsignedchari = 0; i < ast->while_size; i++) {
      func1(ast->while_ast[i], f);
    }
    break;
  caseAST_RETURN:
    func1(ast->right, f);
    break;
    default:
      break;
  }
  free(ast);
}