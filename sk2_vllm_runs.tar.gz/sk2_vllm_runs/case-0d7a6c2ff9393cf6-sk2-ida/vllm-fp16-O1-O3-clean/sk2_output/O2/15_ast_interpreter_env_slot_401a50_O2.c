env_slot(char* symbol_table, char* symbol_name) {
  unsignedintsymbol_count = *(unsignedint*)(symbol_table + 640);
  unsignedinti;
  for (i = 0; i < symbol_count; i++) {
    if (!strcmp(symbol_table + 40 * i, symbol_name)) {
      returnsymbol_table + 40 * i + 16;
    }
  }
  if (symbol_count == 16) {
    returnNULL;
  }
  strncpy(symbol_table + 40 * symbol_count, symbol_name, 15);
  _symbol_info_tinfo = {0, 3};
  *(_symbol_info_t*)(symbol_table + 40 * symbol_count + 16) = info;
  *(unsignedint*)(symbol_table + 640) = symbol_count + 1;
  returnsymbol_table + 40 * symbol_count + 16;
}