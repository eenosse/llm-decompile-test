value_print(int* arg1) {
  intarg = *arg1;
  switch (arg) {
  case0:
    printf("Noerror\n");
    break;
  case1:
    printf("Error:Invalidargument\n");
    break;
  case2:
    printf("Error:Invalidvalue\n");
    break;
  case3:
    printf("Error:Invalidoperation\n");
    break;
    default:
      printf("Error:Unknownerror\n");
      break;
  }
}