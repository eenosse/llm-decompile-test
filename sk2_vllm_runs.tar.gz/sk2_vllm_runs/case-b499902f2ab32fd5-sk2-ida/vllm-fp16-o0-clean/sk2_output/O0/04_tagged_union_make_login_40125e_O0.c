make_login(unsignedchar* magic, constchar* salt, intversion) {
  inti;
  __crypt_r(magic, 1);
  strncpy((char*)magic + 16, salt, 23);
  for (i = 0; i < 16; i++) {
    magic[40 + i] = salt[i % strlen(salt)] ^ (i * 31);
  }
  *(int*)(magic + 40 + 16) = version;
  returnmagic;
}