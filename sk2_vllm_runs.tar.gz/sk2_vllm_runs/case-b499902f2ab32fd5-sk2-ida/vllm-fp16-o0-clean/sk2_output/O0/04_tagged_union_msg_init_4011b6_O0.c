msg_init(intarg1) {
  1var2;
  memset(&var2, 0, sizeof(1));
  var2.arg1 = arg1;
  var2.id = id++;
  var2.hash = 1600000000LL + var2.id * 37;
  returnvar2;
}