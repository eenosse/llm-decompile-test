make_chat(inttype, intid, constchar* name) {
  unsignedchar* tag;
  shortlen;
  tag = _header(type, 3);
  *(int*)(tag + 16) = id;
  strncpy((char*)(tag + 22), name, 95);
  len = (short)strlen((char*)(tag + 22));
  *(short*)(tag + 20) = len;
  returntag;
}