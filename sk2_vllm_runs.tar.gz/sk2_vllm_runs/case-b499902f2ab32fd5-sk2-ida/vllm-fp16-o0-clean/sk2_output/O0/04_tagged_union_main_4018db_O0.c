main(intargc, char** argv) {
  unsignedchecksum = 0;
  type1values[6];
  _init_(&values[0], 0x6666666666666666);
  _init_string(&values[1], "operator", 0x00002a05);
  _init_complex(&values[2], 42, 1.5, -2.25, 0.75);
  _init_string_length(&values[3], 7, "typerecoveryundertest");
  _init_int(&values[4], 99, 24);
  _init_string_length(&values[5], -11, "unsupportedopcode");
  for (inti = 0; i < 6; i++) {
    _print_(&values[i]);
    checksum += _hash_(&values[i]);
  }
  printf("%08x\n", checksum);
  return0;
}