make_move(float* c, intw, floath, floatx, floaty) {
  float* r = _c_rect_alloc(c, 2);
  r[4] = w;
  r[5] = w;
  r[6] = w * 2;
  r[7] = 0;
  r[8] = r[5] + h;
  r[9] = r[6] + x;
  r[10] = r[7] + y;
  r[11] = 120 + 5 * w;
  returnc;
}