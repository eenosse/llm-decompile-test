make_blob(unsignedchar* buf, intid, intlen) {
  inti;
  __builtin_memcpy(buf, 4);
  if (len > 64) len = 64;
  buf[4] = id;
  buf[5] = len;
  for (i = 0; i < len; i++) {
    buf[24 + i] = (id * 13) + (i * 5);
  }
}