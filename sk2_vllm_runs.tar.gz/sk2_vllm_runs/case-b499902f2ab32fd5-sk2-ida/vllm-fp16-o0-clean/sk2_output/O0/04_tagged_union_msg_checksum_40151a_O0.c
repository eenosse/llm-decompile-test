msg_checksum(unsignedchar* data) {
  unsignedinthash = 0x9e3779b1;
  hash = hash * data[0] + data[1];
  switch (data[0]) {
  case0:
    hash = hash ^ data[4] ^ data[5];
    break;
  case1:
    unsignedinti;
    for (i = 0; i < 16; i++) hash = hash * 31 + data[4 + i];
    hash = hash ^ data[4 + 16];
    break;
  case2:
    hash = hash + (int)(100.0f * data[4 + 12]) + (int)(100.0f * data[4 + 8]) +
           data[4];
    hash = hash ^ data[4 + 16];
    break;
  case3:
    hash = hash ^ data[4];
    unsignedinti;
    for (i = 0; i < data[4 + 4]; i++) hash = hash * 131 + data[4 + 6 + i];
    break;
  case4:
    hash = hash ^ data[4];
    unsignedinti;
    for (i = 0; i < data[4 + 4]; i++) hash = hash * 17 + data[4 + 8 + i];
    break;
  case5:
    hash = hash ^ data[4];
    unsignedinti;
    for (i = 0; data[4 + i] != 0; i++) hash = hash * 7 + data[4 + i];
    break;
    default:
      returnhash;
  }
}