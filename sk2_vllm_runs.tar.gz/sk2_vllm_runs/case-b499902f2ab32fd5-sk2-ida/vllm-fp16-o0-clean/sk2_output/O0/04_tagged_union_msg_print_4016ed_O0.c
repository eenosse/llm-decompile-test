msg_print(msg* m) {
  unsignedinti;
  unsignedintj;
  unsignedintk;
  printf("%u%llu%08x%d", m->id, m->time, func2(m), m->type);
  switch (m->type) {
  case0:
    printf("%016llx\n", m->data);
    break;
  case1:
    printf("%s%u%02x\n", m->str, m->len, m->c);
    break;
  case2:
    printf("%d%.1f%.1f%.1f%.1f%.1f%.1f%u\n", m->i, m->x, m->y, m->z, m->a, m->b,
           m->c, m->j);
    break;
  case3:
    printf("%u%u%s\n", m->i, m->k, m->str);
    break;
  case4:
    printf("%u%u%02x%02x\n", m->i, m->k, m->c1, m->c2);
    break;
  case5:
    printf("%d%s\n", m->i, m->str);
    break;
  }
  return;
}