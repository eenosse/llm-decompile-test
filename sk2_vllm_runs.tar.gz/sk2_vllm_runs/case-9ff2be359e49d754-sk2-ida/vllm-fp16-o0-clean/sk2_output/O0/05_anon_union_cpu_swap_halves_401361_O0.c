cpu_swap_halves(unsignedshort* p, inti) {
  unsignedshortt;
  t = p[i];
  p[i] = p[i + 2];
  p[i + 2] = t;
  p[9] += 4;
  return;
}