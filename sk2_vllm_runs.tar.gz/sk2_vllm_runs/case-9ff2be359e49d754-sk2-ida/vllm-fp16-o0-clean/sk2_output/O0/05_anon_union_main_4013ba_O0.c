main(intargc, char** argv) {
  floatargv = -118.625;
  unsignedinta = 0xabcdef00;
  unsignedintb = 0x00000585;
  unsignedintc = 0x000000c8;
  unsignedchard[12] = "vm-core-0";
  unsignedinte[3];
  unsignedintf;
  unsignedintg;
  unsignedinth;
  charih[12];
  unsignedlonglongj;
  j;
  j = 3.14159265358979;
  printf("%.4f%08x%u%u%06x%02x%02x%02x%02x\n", argv, a, b, c, d, e[0], e[1],
         e[2], f);
  printf("%.4f%08x\n", 237.25, 0x44444440);
  printf("%.14f%016llx%08x%08x\n", j, 0x123456789abcdef0, g, ith);
  strcpy(e, d);
  printf("r0", e[0]);
  printf("r3", e[1]);
  memset(e, 0, 7);
  memcpy(e, 3, 3);
  printf("r0'", e[0]);
  printf("r3'", e[1]);
  printf("%08x%u%u%u%u%08x%08x%s\n", f, f & 1, f & 2 ? 1 : 0, f & 4 ? 1 : 0,
         f & 8 ? 1 : 0, g, ith, ih);
  unsignedinti;
  for (i = 0; i < 8; i++) {
    e[i] = i - 96;
  }
  unsignedinti;
  for (i = 0; i < 8; i++) {
    printf("%08x", e[i]);
  }
  printf("\n");
  return0;
}