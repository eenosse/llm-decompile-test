cpu_reset(unsignedchar* buf, constchar* str) {
  inti;
  memset(buf, 0, 56);
  for (i = 0; i < 8; i++) {
    buf[i * 4] = (i + 1) * 0x11111111;
  }
  buf[36] = 0x00000041;
  buf[40] = 0x7FFF8000;
  strncpy((char*)buf + 44, str, 11);
}