cpu_add(unsignedchar* mem, unsignedinta, unsignedintb) {
  intc = *(int*)(mem + a) + *(int*)(mem + b);
  mem[8] = (c & 1) == 1;
  mem[8] = (c == 0) == 1;
  mem[8] = (c < 0) == 1;
  mem[8] = 0;
  *(int*)(mem + a) = c;
  mem[9] += 4;
}