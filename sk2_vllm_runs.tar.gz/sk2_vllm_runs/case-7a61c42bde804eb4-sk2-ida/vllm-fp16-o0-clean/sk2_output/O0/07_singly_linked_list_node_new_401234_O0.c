node_new(intid, char* name, char* surname, intage, shortis_active) {
  void* record = calloc(1, sizeof(record_t));
  if (record == NULL) exit(1);
  record_t* record_ptr = (record_t*)record;
  record_ptr->id = id;
  strncpy(record_ptr->name, name, 19);
  strncpy(record_ptr->surname, surname, 11);
  record_ptr->age = age;
  record_ptr->is_active = is_active;
  returnrecord;
}