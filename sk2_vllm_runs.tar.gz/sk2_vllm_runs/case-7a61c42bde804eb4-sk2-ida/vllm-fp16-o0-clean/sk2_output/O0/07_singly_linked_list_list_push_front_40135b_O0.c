list_push_front(_list_head* head, _list_node* node) {
  node->next = head->head;
  head->head = node;
  if (head->tail == NULL) head->tail = node;
  head->count++;
  head->size += node->length;

#include "list.h"
  void _list_add_head(_list_head * head, _list_node * node) {
    node->next = head->head;
    head->head = node;
    if (head->tail == NULL) head->tail = node;
    head->count++;
    head->size += node->length;
  }