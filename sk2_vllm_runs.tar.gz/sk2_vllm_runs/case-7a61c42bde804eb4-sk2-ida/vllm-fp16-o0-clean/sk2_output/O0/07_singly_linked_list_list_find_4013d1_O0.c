*list_find(Graph* graph, intid) {
  Node* node = graph->head;
  while (node != NULL) {
    if (node->id == id) {
      returnnode;
    }
    node = node->next;
  }
  returnNULL;
}