*merge_sort(_list* head) {
  if (!head || !head->next) {
    returnhead;
  }
  _list* slow = head;
  _list* fast = head->next;
  while (fast && fast->next) {
    slow = slow->next;
    fast = fast->next->next;
  }
  _list* right = slow->next;
  slow->next = NULL;
  _list* left = merge_sort(right);
  _list* newhead = merge_sort(head);
  return_merge(newhead, left);
}