list_push_back(_list_head* head, _list_node* node) {
  node->prev = NULL;
  if (head->tail) head->tail->prev = node;
  elsehead->head = node;
  head->tail = node;
  head->count++;
  head->size += node->length;
}
}