main(intargc, char** argv) {
  HashMaphm;
  _HashMap_init(&hm);
  _HashMap_put(&hm, _HashMap_entry(101, "AdaLovelace", "research", 145000, 9));
  _HashMap_put(&hm, _HashMap_entry(102, "GraceHopper", "compiler", 162000, 14));
  _HashMap_put(&hm, _HashMap_entry(103, "KenThompson", "kernel", 158000, 12));
  _HashMap_put(&hm,
               _HashMap_entry(104, "BarbaraLiskov", "research", 151000, 11));
  _HashMap_put_or_replace(
      &hm, _HashMap_entry(100, "AlanTuring", "research", 170000, 20));
  _HashMap_put(&hm,
               _HashMap_entry(105, "DennisRitchie", "compiler", 149000, 13));
  unsignedchar* e;
  e = _HashMap_get(&hm, 103);
  if (e) {
    printf("%u|%s|%s\n", *(unsigned*)e, e + 4, e + 24);
  }
  _HashMap_print(&hm);
  intcount = _HashMap_count(&hm, "research");
  printf("%d\n", count);
  _HashMap_print(&hm);
  _HashMap_destroy(&hm);
  return0;
}