list_reverse(_list_t_* list) {
  _node_t_* prev = NULL;
  _node_t_* curr = list->head;
  _node_t_* next;
  list->tail = list->head;
  while (curr != NULL) {
    next = curr->next;
    curr->next = prev;
    prev = curr;
    curr = next;
  }
  list->head = prev;
}