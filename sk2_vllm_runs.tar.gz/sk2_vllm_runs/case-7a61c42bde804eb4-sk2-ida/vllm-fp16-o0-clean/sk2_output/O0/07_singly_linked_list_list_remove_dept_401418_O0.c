list_remove_dept(intfunc* f, char* name) {
  inti = 0;
  intfunc_node** n = &f->head;
  while (*n) {
    intfunc_node* m = *n;
    if (!strcmp(m->name, name)) {
      *n = m->next;
      f->count--;
      f->size -= m->size_of_data;
      free(m);
      i++;
    } else {
      n = &m->next;
    }
  }
  f->tail = NULL;
  n = &f->head;
  while (*n) {
    f->tail = *n;
    n = &(*n)->next;
  }
  returni;
}