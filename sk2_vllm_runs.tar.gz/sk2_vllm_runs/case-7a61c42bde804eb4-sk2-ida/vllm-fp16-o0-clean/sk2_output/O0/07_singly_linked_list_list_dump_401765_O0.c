list_dump(Node* node) {
  printf("%zu%llu\n", node->id, node->timestamp);
  Edge* edge = node->edge;while(edge