*merge_sorted(Node* head1, Node* head2) {
  Node *dummy, *tail, *head;
  tail = &dummy;
  head = NULL;
  while (head1 != NULL && head2 != NULL) {
    if (head1->data < head2->data) {
      tail->next = head2;
      head2 = head2->next;
    } else {
      tail->next = head1;
      head1 = head1->next;
    }
    tail = tail->next;
  }
  if (head1 == NULL) {
    tail->next = head2;
  } else {
    tail->next = head1;
  }
  return (head);
}