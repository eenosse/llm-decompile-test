list_free(_list_head* head) {
  _list_node* node = head->next;
  while (node) {
    _list_node* next = node->next_node;
    free(node);
    node = next;
  }
  func0(head);
}