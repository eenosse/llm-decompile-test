vec3_add(complex1a, complex1b) {
  complex1c;
  c.re = a.re + b.re;
  c.im = a.im + b.im;
  returnfunc2(c);
}