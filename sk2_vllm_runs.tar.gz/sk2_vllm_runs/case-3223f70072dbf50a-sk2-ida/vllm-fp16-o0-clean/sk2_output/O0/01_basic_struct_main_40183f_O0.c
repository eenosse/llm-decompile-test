main(intargc, char** argv) {
  node_tnodes[4];
  charname[24];
  unsignedinti;
  unsignedcharcolor[4];
  floatscale;
  node_tnode;
  i = 0;
  for (i = 0; i < 4; i++) {
    snprintf(name, 24, "node_%u", i);
    color[0] = i * 60;
    color[1] = -i * 40;
    color[2] = i * i * 17;
    color[3] = 255;
    node = node_new(i, i * 2);
    scale = 1.0f + i * 0.1f;
    node_setname(&nodes[i], 1000 + i, name, node);
    nodes[i].color = node_color(nodes[i].color, scale);
    node = node_add(nodes[i].color, node);
    nodes[i].color = node_newcolor(nodes[i].color, node);
    node_print(nodes[i].color);
  }
  node = node_new(0.0f, 0.0f);
  scale = 0.25f;
  node_color(node, scale);
  node_print(node);
  for (i = 0; i < 4; i++) {
    node_printnode(&nodes[i]);
  }
  printf("%.2f%.2f%.2f\n", node.r, node.g, node.b);
  return0;
}