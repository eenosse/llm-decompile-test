material_init(struct_s* s, constchar* name, intid, floatvalue) {
  memset(s, 0, sizeof(*s));
  strncpy(s->name, name, 15);
  s->id = id;
  s->id_mask = _mm_set_epi32(id, -1, 128);
  s->value = value;
  s->type = 5;
}