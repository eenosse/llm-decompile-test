vec3_scale(floatx, floaty, floatz) {
  floata = x * z;
  floatb = y * z;
  func2(a, b);
}