object_dump(unsignedchar* p) {
  printf("%llu%s%d%u%.2f\n", *(unsignedlonglong*)p, p + 8, *(short*)(p + 100),
         *(unsignedchar*)(p + 102), *(double*)(p + 104));
  printf("%.2f%.2f%.2f%.2f%.2f%.2f\n", *(float*)(p + 32), *(float*)(p + 36),
         *(float*)(p + 40), *(float*)(p + 56), *(float*)(p + 60),
         *(float*)(p + 64));
  floatf = func2(p);
  printf("%s%02x%02x%02x%02x%.1f%x%.3f\n", p + 68, *(unsignedchar*)(p + 84),
         *(unsignedchar*)(p + 85), *(unsignedchar*)(p + 86),
         *(unsignedchar*)(p + 87), *(float*)(p + 92), *(unsignedint*)(p + 96),
         f);
}