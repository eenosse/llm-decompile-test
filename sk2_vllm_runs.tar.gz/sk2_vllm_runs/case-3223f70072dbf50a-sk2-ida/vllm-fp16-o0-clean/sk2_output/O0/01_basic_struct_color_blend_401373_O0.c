color_blend(unsignedchararg0, unsignedchararg1, unsignedchararg2) {
  unsignedcharresult;
  result = (unsignedchar)((int)arg0 * (255 - arg2) + (int)arg1 * arg2) / 255;
  returnresult;
}