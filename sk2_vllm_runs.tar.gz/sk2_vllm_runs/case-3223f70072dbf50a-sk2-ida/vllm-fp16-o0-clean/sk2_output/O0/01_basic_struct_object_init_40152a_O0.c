object_init(size_tid, constchar* name, doublex, floaty) {
  _1r;
  _1s(&r);
  r.id = id;
  _1c(r.name, name, 23);
  r.x = x;
  r.y = y;
  r.p = _1f(0.0, 0.0);
  r.i = 0;
  r.s = _1f(1.0, 1.0);
  r.f = 1.0f;
  r.c = id % 8;
  r.b = 1;
  r.d = 0.5 + (id % 4) * 0.25;
  returnr;
}