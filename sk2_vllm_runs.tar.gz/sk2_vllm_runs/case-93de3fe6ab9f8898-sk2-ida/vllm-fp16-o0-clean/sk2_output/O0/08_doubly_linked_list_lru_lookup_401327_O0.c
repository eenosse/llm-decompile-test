*lru_lookup(LFUCache* obj, intkey) {
  obj->total_access++;
  LFUCacheNode* node = obj->head;
  while (node != obj) {
    if (node->key == key) {
      node->access++;
      _LFU_Cache_Move_To_Next_Freq(node);
      _LFU_Cache_Move_To_Head(obj, node);
      returnnode;
    }
    node = node->next;
  }
  obj->miss++;
  returnNULL;
}