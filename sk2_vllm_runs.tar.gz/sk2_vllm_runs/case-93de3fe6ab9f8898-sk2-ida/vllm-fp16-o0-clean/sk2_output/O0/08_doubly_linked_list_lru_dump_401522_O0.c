lru_dump(list* l) {
  size_ti = 0;
  size_tj = 0;
  node* n;
  node* m;
  printf("%zu\n", l->size);
  n = l->head;
  while (n != l) {
    printf("%u|%s|%u\n", n->id, n->name, n->age);
    n = n->next;
    i++;
  }
  m = l->tail;while(m