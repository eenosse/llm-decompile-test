lru_put(HashMap* map, unsignedkey, constchar* value) {
  HashMapNode* node = _findNode(map, key);
  if (node) {
    strncpy(node->value, value, 23);
  }
  if (map->size == map->capacity) {
    node = map->tail;
    printf("%u|%s|%u\n", node->key, node->value, node->hash);
    _removeNode(node);
    free(node);
    map->size--;
    map->deleted++;
  }
  node = calloc(1, sizeof(HashMapNode));
  if (!node) {
    exit(1);
  }
  node->key = key;
  strncpy(node->value, value, 23);
  _addNode(map, node);
  map->size++;
}