*lru_init(list_t* list, list_node_t* node) {
  memset(list, 0, sizeof(list_t));
  list->next = list;
  list->prev = list;
  list->node = node;
  returnlist;
}