lru_rotate(Stack* stack, intcount) {
  inti;
  while ((i = count--) > 0) {
    if (stack->count < 2) return;
    Object* obj = stack->top;
    func2(obj);
    func3(stack, obj);
  }
}