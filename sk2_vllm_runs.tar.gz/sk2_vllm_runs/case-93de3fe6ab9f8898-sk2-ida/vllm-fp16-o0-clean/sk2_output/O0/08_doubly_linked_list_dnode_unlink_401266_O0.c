dnode_unlink(_list_elem_t_* elem) {
  elem->prev->next = elem->next;
  elem->next->prev = elem->prev;
  elem->prev = NULL;
  elem->next = NULL;
}