main(intargc, char** argv) {
  unsignedpages[] = {1, 2, 3, 2, 4, 1, 5, 3, 6, 2, 2, 7};
  hashmap_tmap;
  _hashmap_init(&map, 4);
  unsignedi;
  for (i = 0; i < 12; i++) {
    charbuf[24];
    snprintf(buf, 24, "page-%02u", pages[i]);
    printf("%u\n", pages[i]);
    _hashmap_set(&map, pages[i], buf);
  }
  hashmap_print(&map);
  printf("%d\n", _hashmap_get(&map, 2) != NULL);
  printf("%d\n", _hashmap_get(&map, 99) != NULL);
  hashmap_print(&map);
  _hashmap_remove(&map, 2);
  hashmap_print(&map);
  printf("%llu%llu%llu%.1f\n", map.used, map.size, map.buckets,
         100.0 * (double)map.used / (double)map.size);
  _hashmap_free(&map);
  return0;
}