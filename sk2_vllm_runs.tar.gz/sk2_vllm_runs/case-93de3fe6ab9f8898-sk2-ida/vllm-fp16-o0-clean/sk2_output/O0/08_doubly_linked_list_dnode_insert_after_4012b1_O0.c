dnode_insert_after(_list_node_t_* a, _list_node_t_* b) {
  b->next = a;
  b->prev = a->prev;
  a->prev->next = b;
  a->prev = b;
  a = a;
}