lru_free(_list_head* head) {
  _list_head *p, *q;
  for (p = head->next; p != head; p = q) {
    q = p->next;
    free(p);
  }
  head->next = head->prev = head;
  head->len = 0;
}