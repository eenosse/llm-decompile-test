act_establish(unsignedchar* param1) {
  intv0 = *(int*)(param1 + 0x48);
  memset((param1 + 0x48), 0, 0x20);
  *(int*)(param1 + 0x58) = v0 + 1;
  *(short*)(param1 + 0x5c) = 0x5a4;
  *(unsignedchar*)(param1 + 0x5e) = 1;
}
}