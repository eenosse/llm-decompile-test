act_data(unsignedchar** p) {
  p[12] += (p[9] + 64) * 8;
  p[13] += (p[9] + 64) * 3;
  p[14] += p[12] & 0xff;
  ;
}