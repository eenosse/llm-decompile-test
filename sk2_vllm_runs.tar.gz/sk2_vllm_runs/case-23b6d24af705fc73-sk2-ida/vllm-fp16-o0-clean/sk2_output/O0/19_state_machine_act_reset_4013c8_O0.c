act_reset(unsignedchar* buf, intlen) {
  memset(buf + 72, 0, 32);
  buf[72] = len | 0x80;
  strncpy((char*)buf + 76, "peerreset", 23);
}