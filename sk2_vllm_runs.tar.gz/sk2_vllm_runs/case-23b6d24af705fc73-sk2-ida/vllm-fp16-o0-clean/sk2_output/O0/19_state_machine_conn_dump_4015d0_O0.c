conn_dump(unsignedchar* p) {
  unsignedinti;
  intj;
  printf("%u|%s|%d%d%u%u\n", *(unsignedint*)p, p + 4, *(int*)(p + 28),
         *(int*)(p + 32), *(unsignedint*)(p + 36), *(unsignedint*)(p + 40));
  i = *(int*)(p + 28);
  switch (i) {
  case0:
    printf("%x|%s\n", *(unsignedint*)(p + 72), p + 76);
    break;
  case3:
    printf("%08x%08x%u%u\n", *(unsignedint*)(p + 72), *(unsignedint*)(p + 76),
           *(unsignedshort*)(p + 80), *(unsignedchar*)(p + 82));
    break;
  case5:
    printf("%x|%s\n", *(unsignedint*)(p + 72), p + 76);
    break;
  case1:
  case2:
  case4:
    printf("%llu%llu%08x%u%u\n", *(unsignedlonglong*)(p + 72),
           *(unsignedlonglong*)(p + 80), *(unsignedint*)(p + 88),
           *(unsignedshort*)(p + 92), *(unsignedchar*)(p + 94));
    break;
  }
  for (j = 0; j < 7; j++) {
    printf("%u", *(unsignedint*)(p + 12 + j * 4));
  }
  printf("\n");
}