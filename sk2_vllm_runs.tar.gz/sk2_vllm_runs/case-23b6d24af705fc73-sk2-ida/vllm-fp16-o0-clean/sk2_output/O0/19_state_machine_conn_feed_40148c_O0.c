conn_feed(int* mem, inty) {
  int* p = mem + 168 + mem[7] * 24 + y;
  mem[11 + y]++;
  if (p[0] == mem[7] && p[1] == 0) {
    mem[10]++;
    printf("%d%d%d0\n", mem[7], y, mem[7]);
  } else {
    if (p[1] != 0) {
      ((void (*)(int*, int))p[1])(mem, y);
    }
    mem[8] = mem[7];
    mem[7] = p[0];
    mem[9]++;
    printf("%d%d%d1\n", mem[8], y, mem[7]);
  }
}