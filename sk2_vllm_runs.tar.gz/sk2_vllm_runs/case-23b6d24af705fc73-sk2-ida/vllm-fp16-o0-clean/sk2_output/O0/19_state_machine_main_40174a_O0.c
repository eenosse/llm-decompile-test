main(intargc, char** argv) {
  staticconstchar* hosts[] = {"10.0.0.7:443", "10.0.0.7:443", "10.0.0.7:443",
                              "10.0.0.7:443", "10.0.0.7:443", "10.0.0.7:443",
                              "10.0.0.7:443", "10.0.0.7:443"};
  staticconstchar* hosts2[] = {
      "192.168.1.9:80", "192.168.1.9:80", "192.168.1.9:80", "192.168.1.9:80",
      "192.168.1.9:80", "192.168.1.9:80", "192.168.1.9:80"};
  staticconstunsignedhosts_index[] = {0, 1, 2, 3, 4, 5, 6, 7};
  staticconstunsignedhosts2_index[] = {0, 1, 2, 3, 4, 5, 6};
  staticunsignedhosts_map[7][3];
  staticunsignedcount;
  unsignedi, j;
  init_map(hosts_map[0], 1, hosts[0]);
  init_map(hosts_map[1], 2, hosts2[0]);
  for (i = 0; i < 8; i++) {
    add_host(hosts_map[0], hosts_index[i]);
  }
  print_map(hosts_map[0]);
  for (i = 0; i < 8; i++) {
    add_host(hosts_map[1], hosts_index[i]);
  }
  print_map(hosts_map[1]);
  count = 0;
  for (i = 0; i < 6; i++) {
    for (j = 0; j < 7; j++) {
      if (hosts_map[i][j]) {
        count++;
      }
    }
  }
  printf("%zu%u\n", sizeof(hosts_map) / sizeof(hosts_map[0]), count);
  return0;
}