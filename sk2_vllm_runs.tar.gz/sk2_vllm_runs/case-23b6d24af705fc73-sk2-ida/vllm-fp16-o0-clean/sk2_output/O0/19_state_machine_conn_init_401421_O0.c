conn_init(struct_s* s, intid, constchar* name) {
  memset(s, 0, sizeof(*s));
  s->id = id;
  strncpy(s->name, name, 24 - 1);
  s->a = 0;
  s->b = 0;
}