act_close(unsignedchar* buf, inti) {
  unsignedlonglongll;
  memcpy(&ll, buf + 16, 8);
  memcpy(&ll, &ll + 8, 8);
  memset(buf + 16, 0, 32);
  *(int*)&buf[16] = i;
  snprintf((char*)buf + 16 + 4, 24, "graceful%lluB", ll);
}