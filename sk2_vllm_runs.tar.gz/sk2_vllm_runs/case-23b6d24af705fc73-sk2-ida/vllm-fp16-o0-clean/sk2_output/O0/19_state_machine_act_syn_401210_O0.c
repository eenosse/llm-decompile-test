act_syn(unsignedchar* x) {
  x[18] = 7 * x[0] + 4096;
  x[19] = 13 * x[0] + 36864;
  x[21] = 0;
}