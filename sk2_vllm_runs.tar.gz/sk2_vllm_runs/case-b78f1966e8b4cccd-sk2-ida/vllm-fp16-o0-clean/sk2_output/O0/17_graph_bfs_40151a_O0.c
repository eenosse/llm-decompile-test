bfs(unsignedshort* edges, unsignedshortnode, unsignedchar* data) {
  unsignedshorti;
  unsignedshortj;
  unsignedshort* edge;
  func2(data, edges[192], data);
  data[node] = 0;
  data[72 + node] = 1;
  data[34]++;
  data[42 + data[34] - 1] = node;
  while (data[33] < data[34]) {
    i = data[33];
    data[33]++;
    j = data[42 + i - 1];
    data[35]++;
    edge = edges[72 + j];
    while (edge != NULL) {
      if (data[72 + *edge] == 0) {
        data[72 + *edge] = 1;
        data[*edge] = data[j] + 1;
        data[24 + *edge] = j;
        data[34]++;
        data[42 + data[34] - 1] = *edge;
      }
      edge++;
      edge++;
    }
  }
}