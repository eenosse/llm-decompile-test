print_matrix(unsignedshort* a) {
  unsignedshorti, j;
  for (i = 0; i < a[48]; i++) {
    printf("%s", (char*)a + 48 * i);
    for (j = 0; j < a[48]; j++) {
      if (a[48 * 12 + i * 12 + j] == 0) printf("0");
      elseprintf("%u", a[48 * 12 + i * 12 + j]);
    }
    printf("\n");
  }
}