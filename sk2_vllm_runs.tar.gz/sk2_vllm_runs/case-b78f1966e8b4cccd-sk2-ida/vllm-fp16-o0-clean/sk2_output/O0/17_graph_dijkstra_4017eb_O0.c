dijkstra(Graph* graph, unsignedshortnode, unsignedint* array) {
  inti;
  intmin;
  intj;
  unsignedshort* edge;
  intdist;
  _memcpy(array, graph->nodes);
  array[node] = 0;
  for (i = 0; i < graph->nodes; i++) {
    min = -1;
    for (j = 0; j < graph->nodes; j++) {
      if (array[72 + j] == 0) {
        if (min < 0 || array[j] < array[min]) {
          min = j;
        }
      }
    }
    if (min < 0) {
      return;
    }
    if (array[min] == 1000000) {
      return;
    }
    array[72 + min] = 1;
    array[35]++;
    edge = graph->edges[min];while(edge