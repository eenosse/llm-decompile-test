state_reset(unsignedchar* p, unsignedshortn) {
  unsignedshorti;
  memset(p, 0, 36 * 4);
  for (i = 0; i < n; i++) {
    *((unsignedint*)(p + i * 4)) = 1000000;
    *((unsignedshort*)(p + 36 + i * 2)) = 0xffff;
  }
}