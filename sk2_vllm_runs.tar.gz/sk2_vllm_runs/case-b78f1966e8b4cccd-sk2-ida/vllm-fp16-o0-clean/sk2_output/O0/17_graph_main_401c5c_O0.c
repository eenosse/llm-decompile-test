main(intargc, char** argv) {
  intargv = argv;
  argc = argc;
  unsignedshortfrom = -1;
  unsignedshortto = -1;
  memset(g, 0, 1544);
  unsignedshortHAN = addcity(g, "HAN", "Hanoi", 29000000, 21.03, 105.85);
  unsignedshortSGN = addcity(g, "SGN", "HoChiMinh", 41000000, 10.82, 106.63);
  unsignedshortHKG = addcity(g, "HKG", "HongKong", 71000000, 22.31, 113.91);
  unsignedshortNRT = addcity(g, "NRT", "Tokyo", 42000000, 35.77, 140.39);
  unsignedshortLHR = addcity(g, "LHR", "London", 80000000, 51.47, -0.45);
  unsignedshortCDG = addcity(g, "CDG", "Paris", 76000000, 49.01, 2.55);
  unsignedshortDXB = addcity(g, "DXB", "Dubai", 89000000, 25.25, 55.36);
  unsignedshortSIN = addcity(g, "SIN", "Singapore", 68000000, 1.36, 103.99);
  unsignedshortSFO =
      addcity(g, "SFO", "SanFrancisco", 57000000, 37.62, -122.38);
  unsignedshortJFK = addcity(g, "JFK", "NewYork", 62000000, 40.64, -73.78);
  addflight(g, HAN, SGN, 125, 90);
  addflight(g, HAN, HKG, 105, 180);
  addflight(g, SGN, SIN, 110, 140);
  addflight(g, HKG, NRT, 230, 320);
  addflight(g, HKG, CDG, 505, 640);
  addflight(g, SIN, CDG, 445, 590);
  addflight(g, CDG, LHR, 430, 700);
  addflight(g, LHR, CDG, 80, 120);
  addflight(g, NRT, SFO, 585, 880);
  addflight(g, SFO, JFK, 330, 260);
  addflight(g, LHR, JFK, 425, 540);
  printf("%u%u\n", g.n, g.m);
  for (unsignedshorti = 0; i < g.n; ++i) {
    printf("%s|%s|%.2f|%.2f|%u", g.cities[i].name, g.cities[i].country,
           g.cities[i].lat, g.cities[i].lon, g.cities[i].population);
    flight* f = g.cities[i].flights;
    while (f) {
      printf("%s%u%u", g.cities[f->to].name, f->cost, f->time);
      f = f->next;
    }
    putchar('\n');
  }
  printpath(&g);
  int* path;
  findpath(&g, HAN, &path);
  for (unsignedshorti = 0; i < g.n; ++i) {
    char* name = path[i] < 0 ? "-" : g.cities[path[i]].name;
    intcost = path[i] == 1000000 ? -1 : path[i];
  }
  return0;
}