dfs_matrix(unsignedshort* data, unsignedshortnode, unsignedchar* visited,
           unsignedintdepth) {
  visited[72 + node] = 1;
  visited[140]++;
  printf("%u%s\n", depth, (char*)&data[12 * node]);
  unsignedshorti;
  for (i = 0; i < data[344]; i++) {
    if (data[12 * node + 336 + i] != 0) {
      if (visited[72 + i] == 0) {
        visited[24 + i * 2] = node;
        func1(data, i, visited, depth + 1);
      }
    }
  }
}