print_path(char* s, unsignedshort* a, shorti) {
  intj = 0;
  shortb[12];
  shortc;
  shortd;
  d = i;
  while (d >= 0 && j < 12) {
    b[j++] = d;
    d = a[24 + d];
  }
  while (j-- > 0) {
    printf("%s%s", s + 48 * b[j], j ? "" : ":");
  }
  printf("%d\n", a[i]);
}