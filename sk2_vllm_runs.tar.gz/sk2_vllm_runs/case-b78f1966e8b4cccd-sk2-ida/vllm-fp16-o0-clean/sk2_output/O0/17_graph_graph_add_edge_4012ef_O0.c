graph_add_edge(unsignedchar* mem, unsignedshorta, unsignedshortb, shortc,
               intd) {
  unsignedshort* ptr;
  unsignedshort* ptr2;
  unsignedshorte;
  unsignedshort* ptr3;
  ptr = (unsignedshort*)calloc(1, 16);
  if (ptr == NULL) exit(1);
  ptr[0] = b;
  ptr[1] = c;
  *(int*)(ptr + 2) = d;
  ptr3 = (unsignedshort*)(mem + (72 + a * 12));
  ptr[3] = *ptr3;
  *ptr3 = (unsignedshort)ptr;
  ptr3 = (unsignedshort*)(mem + (336 + a * 12 + b));
  *ptr3 = c;
  e = *(unsignedshort*)(mem + 1538);
  if (e < 48) {
    ptr2 = (unsignedshort*)(mem + 960 + e * 12);
    *ptr2++ = a;
    *ptr2++ = b;
    *ptr2++ = c;
    *(int*)ptr2 = d;
  }
  return;
}