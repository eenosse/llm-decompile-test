graph_free(_HASH_TABLE_* ht) {
  unsignedshorti;
  _HASH_TABLE_NODE_ *p, *q;
  for (i = 0; i < ht->size; i++) {
    p = ht->table[i];
    while (p != NULL) {
      q = p->next;
      free(p);
      p = q;
    }
    ht->table[i] = NULL;
  }
}