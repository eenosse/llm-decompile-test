graph_add_vertex(void* handle, char* funcname, char* arg1, intarg2, doublearg3,
                 doublearg4) {
  char* buf;
  buf = (char*)((char*)handle + 48 + *((unsignedshort*)((char*)handle + 1536)));
  memset(buf, 0, 48);
  strncpy(buf, funcname, 3);
  strncpy(buf + 4, arg1, 15);
  *((double*)(buf + 12)) = arg3;
  *((double*)(buf + 24)) = arg4;
  *((int*)(buf + 36)) = arg2;
  intret = *((unsignedshort*)((char*)handle + 1536));
  *((unsignedshort*)((char*)handle + 1536)) = ret + 1;
  returnret;
}