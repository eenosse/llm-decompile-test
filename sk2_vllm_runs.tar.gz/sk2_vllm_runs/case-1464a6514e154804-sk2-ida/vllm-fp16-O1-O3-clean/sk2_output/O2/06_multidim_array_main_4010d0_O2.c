main(intargc, char** argv) {
  intargv = 0;
  memset(table, 0, 1080);
  table[0] = 'A';
  table[1] = 'B';
  table[2] = 'C';
  table[3] = 'D';
  table[4] = 'E';
  table[5] = 'F';
  table[6] = 'G';
  table[7] = 'H';
  table[8] = 'I';
  table[9] = 'J';
  table[10] = 'K';
  table[11] = 'L';
  table[12] = 'M';
  table[13] = 'N';
  table[14] = 'O';
  table[15] = 'P';
  table[16] = 'Q';
  table[17] = 'R';
  table[18] = 'S';
  table[19] = 'T';
  table[20] = 'U';
  table[21] = 'V';
  table[22] = 'W';
  table[23] = 'X';
  table[24] = 'Y';
  table[25] = 'Z';
  table[26] = 'a';
  table[27] = 'b';
  table[28] = 'c';
  table[29] = 'd';
  table[30] = 'e';
  table[31] = 'f';
  table[32] = 'g';
  table[33] = 'h';
  table[34] = 'i';
  table[35] = 'j';
  table[36] = 'k';
  table[37] = 'l';
  table[38] = 'm';
  table[39] = 'n';
  table[40] = 'o';
  table[41] = 'p';
  table[42] = 'q';
  table[43] = 'r';
  table[44] = 's';
  table[45] = 't';
  table[46] = 'u';
  table[47] = 'v';
  table[48] = 'w';
  table[49] = 'x';
  table[50] = 'y';
  table[51] = 'z';
  table[52] = '0';
  table[53] = '1';
  table[54] = '2';
  table[55] = '3';
  table[56] = '4';
  table[57] = '5';
  table[58] = '6';
  table[59] = '7';
  table[60] = '8';
  table[61] = '9';
  table[62] = '+';
  table[63] = '/';
  for (inti = 0; i < 8; i++) {
    for (intj = 0; j < 8; j++) {
      table[64 + i * 32 + j] = (i < 4 ? j + 1 : 1);
      table[64 + i * 32 + j + 1] = (i < 4 ? 1 : j + 1);
      table[64 + i * 32 + j + 2] = 0;
      table[64 + i * 32 + j + 3] = 0;
      table[128 + i * 8 + j] = 1 << j;
    }
  }
  for (inti = 0; i < 3; i++) {
    for (intj = 0; j < 8; j++) {
      table[192 + i * 8 + j] = i * j * j - j;
    }
  }
  table[256] = '=';
  table[257] = '=';
  table[258] = '=';
  table[259] = '=';
  table[260] = '=';
  table[261] = '=';
  table[262] = '=';
  table[263] = '=';
  table[264] = '=';
  table[265] = '=';
  table[266] = '=';
  table[267] = '=';
  table[268] = '=';
  table #Whatisthesourcecode ? main(intargc, char** argv) {
    intargv = 0;
    memset(table, 0, 1080);
    table[0] = 'A';
    table[1] = 'B';
    table[2] = 'C';
    table[3] = 'D';
    table[4] = 'E';
    table[5] = 'F';
    table[6] = 'G';
    table[7] = 'H';
    table[8] = 'I';
    table[9] = 'J';
    table