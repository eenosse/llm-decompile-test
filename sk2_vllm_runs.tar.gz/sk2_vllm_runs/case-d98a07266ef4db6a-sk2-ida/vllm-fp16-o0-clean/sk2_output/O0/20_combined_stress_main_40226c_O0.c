main(intargc, char** argv) {
  Playerplayer = {0};
  player.money = 1;
  Container* world = newcontainer("world", 16, 16, 16);
  Container* backpack = newcontainer("backpack", 6, 4, 2);
  Container* chest = newcontainer(world, backpack);
  Container* pouch = newcontainer(world, chest);
  Item* sword = newitem(&player, "ironsword", 0, 12500);
  sword->damage = 12;
  sword->durability = 28;
  sword->weight = 7;
  memcpy(sword->name, "steel", 6);
  additem(chest, sword);
  Item** items = additemptr(items, sword, 0);
  Item* potion = newitem(&player, "elixir", 1, 3200);
  potion->damage = 120;
  potion->durability = 45;
  potion->value = 300;
  potion->weight = 3;
  additem(chest, potion);
  items = additemptr(items, potion, 0);
  Item* key = newitem(&player, "brasskey", 2, 500);
  key->key = 4711;
  for (inti = 0; i < 8; i++) {
    key->name[i] = 90 + i * 3;
  }
  additem(pouch, key);
  items = additemptr(items, key, 0);
  Item* tablet = newitem(&player, "runetablet", 3, 8800);
  tablet->container = getcontainer("RuneofFire", 8, 8);
  printf("%d%u\n", getitemid(tablet), tablet->id);
  printf("%d%u\n", getitemid(tablet), tablet->id);
  Item* kit = newitem(&player, "starterkit", 4, 15000);
  kit->container = chest;
  kit->quantity = 20;
  additem(pouch, kit);
  items = additemptr(items, kit, 0);
  printcontainer(world, 0);
  printitem(chest, sword);
  printitemptr(items, 3);
  intitemid = itemid ? itemid->itemid : -1;
  constchar* itemname = itemid ? itemid->itemname : "N/A";
  printf("%s|%d\n", itemname, itemid);
  unsignedhash = getcontainerhash(world);
  printf("%llu%u%u\n", hash, player.level, player.money);
  freeitemptr(items);
  freecontainer(world);
  return0;
}