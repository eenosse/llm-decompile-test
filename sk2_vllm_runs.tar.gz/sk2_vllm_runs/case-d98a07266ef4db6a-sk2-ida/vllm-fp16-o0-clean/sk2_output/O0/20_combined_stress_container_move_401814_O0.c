container_move(unsignedchar** mem, unsignedchar** reg, unsignedint* pc) {
  unsignedshorti, j;
  mem_write(pc + 7);
  mem[10]--;
  for (i = 0; i < 4; i++) {
    for (j = 0; j < 6; j++) {
      if (mem[12 + i * 6 + j] == pc[0]) {
        mem[12 + i * 6 + j] = 0;
      }
    }
  }
  func2(reg, pc);
}