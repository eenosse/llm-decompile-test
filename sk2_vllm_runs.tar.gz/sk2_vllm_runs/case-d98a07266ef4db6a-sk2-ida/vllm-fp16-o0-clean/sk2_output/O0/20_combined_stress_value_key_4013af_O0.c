value_key(unsignedchar* data) {
  intresult = data[18];
  inti;
  for (i = 0; i < 8; i++) result = 3 * result + data[18 + 4 + i];
  returnresult % 5000;
}