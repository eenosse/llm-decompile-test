value_script(unsignedchar** args) {
  unsignedshort* arg;
  intret;
  if (arg = (unsignedshort*)args[9]) {
    ret = arg[0] * 11 + arg[1] * 7 + *(int*)(args + 10);
  } else {
    ret = 0;
  }
  returnret;
}