script_run(unsignedchar** arg) {
  unsignedshort* p;
  inti;
  unsignedcharc;
  intn = 0;
  intstack[16];
  p = (unsignedshort*)(arg[9]);
  if (p == NULL) return0;
  arg[10] = (int*)arg[10] + 1;
  for (i = 0; i < p[0]; i++) {
    c = p[i + 1];
    switch (c >> 4) {
    case0:
      if (n < 16) stack[n++] = c & 0x0f;
      break;
    case1:
      if (n >= 2) {
        stack[n - 2] += stack[n - 1];
        n--;
      }
      break;
    case2:
      if (n >= 2) {
        stack[n - 2] *= stack[n - 1];
        n--;
      }
      break;
    case3:
      if (n >= 2) {
        stack[n - 2] -= stack[n - 1];
        n--;
      }
      break;
    case4:
      if (n >= 1) stack[n - 1] = -stack[n - 1];
      break;
    }
  }
  if (n >= 1) returnstack[n - 1];
  elsereturn0;
}