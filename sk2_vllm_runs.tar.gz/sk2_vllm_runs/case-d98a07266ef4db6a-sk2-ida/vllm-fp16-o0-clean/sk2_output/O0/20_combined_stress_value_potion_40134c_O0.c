value_potion(short* args) {
  inta = args[18] + args[19];
  if (a < 0) a = -a;
  a = a * 2 + args[20] / 10;
  return (args[21] * a);
}