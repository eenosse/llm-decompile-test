container_attach(node* a, node* b) {
  node* c = a + 1;
  while (c->next) {
    c = c->next;
  }
  c->next = b;
  b->prev = a;
}