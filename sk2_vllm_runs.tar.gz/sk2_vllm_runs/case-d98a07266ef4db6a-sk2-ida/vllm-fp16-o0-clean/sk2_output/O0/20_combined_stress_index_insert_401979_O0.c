*index_insert(node* root, int* data, intlevel) {
  if (root == NULL) {
    root = calloc(1, sizeof(node));
    if (root == NULL) exit(1);
    root->data = *data;
    root->address = data;
    root->level = level;
    returnroot;
  }
  if (*data < root->data) {
    root->left = index_insert(root->left, data, level + 1);
    returnroot;
  }
  root->right = index_insert(root->right, data, level + 1);
  returnroot;
}