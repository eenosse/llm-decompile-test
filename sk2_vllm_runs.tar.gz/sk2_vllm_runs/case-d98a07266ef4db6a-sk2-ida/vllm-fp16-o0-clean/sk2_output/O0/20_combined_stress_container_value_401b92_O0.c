container_value(Node* node) {
  intsum = 0;
  Node* child;
  Node* sibling;
  _foreach(child, node->children) {
    if (child->intfunc2) {
      sum += child->intfunc2(child);
    }
  }
  _foreach(sibling, node->siblings) { sum += func1(sibling); }
  returnsum;
}