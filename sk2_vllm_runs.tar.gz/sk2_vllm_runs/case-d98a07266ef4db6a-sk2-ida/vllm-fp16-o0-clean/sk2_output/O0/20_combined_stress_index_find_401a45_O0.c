index_find(_bst_node_t* root, intkey) {
  while (root) {
    if (key == root->key) {
      returnroot->value;
    }
    elseif(key < root->key) { root = root->left; }
    else {
      root = root->right;
    }
  }
  return0;
}