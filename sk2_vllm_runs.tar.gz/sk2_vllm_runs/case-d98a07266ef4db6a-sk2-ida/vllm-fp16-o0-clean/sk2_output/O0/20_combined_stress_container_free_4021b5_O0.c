container_free(Node* node) {
  Node *node1, *node2;
  Node *node3, *node4;
  for (node1 = node->children.next; node1 != &node->children; node1 = node2) {
    node2 = node1->next;
    Pair* pair = findpair(node1, STRING, IDENTIFIER);
    if (pair->key == STRING_VALUE) free(pair->value);
    free(pair);
  }
  for (node3 = node->child; node3; node3 = node4) {
    node4 = node3->sibling;
    func1(node3);
  }
  free(node);
}