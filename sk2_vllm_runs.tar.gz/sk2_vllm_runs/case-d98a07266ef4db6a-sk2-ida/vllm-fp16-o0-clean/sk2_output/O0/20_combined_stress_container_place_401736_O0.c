container_place(unsignedchar* state, unsignedint* input) {
  unsignedchar* temp;
  unsignedshorti, j;
  func2(state + 24, input + 7);
  temp = state;
  *((unsignedint*)(temp + 40)) += 1;
  for (i = 0; i < 4; i++) {
    for (j = 0; j < 6; j++) {
      if (state[64 + 9 + i * 6 + j] == 0) {
        temp = state + 64 + 9 + i * 6 + j;
        *temp = *input;
        return;
      }
    }
  }
  return;
}