value_bundle(value_bundle_t* p) {
  inti;
  if (p->i) i = func2(p->i);
  elsei = 0;
  returni*(100 - p->j) / 100;
}