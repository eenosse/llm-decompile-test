*container_new(constchar* name, shortx, shorty, shortz) {
  _node* node;
  node = calloc(1, sizeof(_node));
  if (node == NULL) exit(1);
  strncpy(node->name, name, 15);
  node->x = x;
  node->y = y;
  node->z = z;
  _new_list(node->list);
  returnnode;
}