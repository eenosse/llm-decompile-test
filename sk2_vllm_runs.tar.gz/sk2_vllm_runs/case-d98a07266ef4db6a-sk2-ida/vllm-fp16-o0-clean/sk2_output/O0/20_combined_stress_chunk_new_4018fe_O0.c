chunk_new(unsignedshort* data, unsignedshortlength, shortorder) {
  unsignedshort* packed;
  packed = malloc(length + 4);
  if (packed == NULL) exit(1);
  *((unsignedshort*)packed) = length;
  *((unsignedshort*)(packed + 2)) = order;
  memcpy(packed + 4, data, length);
  returnpacked;
}