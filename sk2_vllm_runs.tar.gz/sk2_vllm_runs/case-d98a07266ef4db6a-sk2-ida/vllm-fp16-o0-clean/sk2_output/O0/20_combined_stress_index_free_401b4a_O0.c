index_free(_node_t* node) {
  if (node == NULL) return;
  _func1(node->left);
  _func1(node->right);
  free(node);
}