item_new(ThreadPool* pool, constchar* name, inttype, void* arg) {
  Thread* thread = calloc(1, sizeof(Thread));
  if (thread == NULL) exit(1);
  thread->id = pool->thread_id++;
  strncpy(thread->name, name, 19);
  thread->type = type;
  thread->arg = arg;
  thread->priority = 100;
  thread->state = THREAD_STATE_READY;
  thread->cpu_id = (thread->id % 3) + 1;
  thread->mem_id = (thread->id % 2) + 1;
  thread->run_count = 1;
  __new_mutex(&thread->mutex);
  switch (type) {
  caseTHREAD_TYPE_TIMER:
    thread->func = __thread_timer;
    break;
  caseTHREAD_TYPE_TASK:
    thread->func = __thread_task;
    break;
  caseTHREAD_TYPE_TASK_WITH_ARG:
    thread->func = __thread_task_with_arg;
    break;
  caseTHREAD_TYPE_TASK_WITH_RETURN:
    thread->func = __thread_task_with_return;
    break;
  caseTHREAD_TYPE_TASK_WITH_ARG_AND_RETURN:
    thread->func = __thread_task_with_arg_and_return;
    break;
  }
}