grid_fill(charbuf[6][32]) {
  inti;
  for (i = 0; i < 6; i++) {
    snprintf(buf[i], 32, "row-%d:%.*s", i, i * 3, "############");
    buf[i + 48][0] = strlen(buf[i]);
  }
}