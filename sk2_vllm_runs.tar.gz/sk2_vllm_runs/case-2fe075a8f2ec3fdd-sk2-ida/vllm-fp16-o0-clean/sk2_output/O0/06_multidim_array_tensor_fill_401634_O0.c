tensor_fill(short* a) {
  inti, j, k, l;
  a[0] = 2;
  a[1] = 3;
  a[2] = 4;
  a[3] = 5;
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      for (k = 0; k < 4; k++) {
        for (l = 0; l < 5; l++) {
          a[4 * (i * 20 + j * 5 + k * 1 + l) + 4] =
              (double)(i * 100 + j * 20 + k * 5 + l) / 7;
        }
      }
    }
  }
}