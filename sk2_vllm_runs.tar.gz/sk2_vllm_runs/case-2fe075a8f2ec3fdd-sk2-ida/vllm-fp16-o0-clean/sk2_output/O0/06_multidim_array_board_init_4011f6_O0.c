board_init(unsignedchar* mem, constchar* name) {
  memset(mem, 0, 1084);
  strncpy((char*)mem, name, 15);
  for (inty = 0; y < 8; y++) {
    for (intx = 0; x < 8; x++) {
      unsignedchar* p = mem + 16 + y * 32 + x * 4;
      p[0] = (y + x) % 5 == 0 ? (y * x) % 6 + 1 : 0;
      p[1] = p[0] ? (y < 4 ? 1 : 2) : 0;
      p[2] = p[0] * 10 + y - x;
      if (p[0]) mem[1076 + y] |= 1 << x;
    }
  }
  for (intz = 0; z < 3; z++) {
    for (inty = 0; y < 8; y++) {
      for (intx = 0; x < 8; x++) {
        int* q = (int*)(mem + 256 + z * 256 + y * 32 + x * 4);
        *q = (x - y) * (z + 1);
      }
    }
  }
  for (intz = 0; z < 3; z++) {
    for (intx = 0; x < 3; x++) {
      int* q = (int*)(mem + 260 + z * 96 + x * 4);
      *q = z == 1 && x == 1 ? 0.5f : 0.25f;
    }
  }
}