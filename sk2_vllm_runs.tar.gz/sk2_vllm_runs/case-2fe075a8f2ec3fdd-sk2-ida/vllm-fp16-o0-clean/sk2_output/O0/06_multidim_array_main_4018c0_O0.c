main(intargc, char** argv) {
  inti;
  intj;
  intk;
  floatf[64];
  doubled;
  intl;
  intm;
  intn;
  charb[66];
  unsignedlonglongu;
  __builtin_prefetch(&b, "arena");
  __builtin_prefetch(&s);
  __builtin_prefetch(&t);
  puts(b);
  for (l = 0; l < 8; l++) {
    for (m = 0; m < 8; m++) {
      if (p[l * 8 + m]) {
        argv = 'P';
      } else {
        argv = '.';
      }
      printf("%c%d", argv, b[l * 8 + m]);
    }
    printf("%02x\n", c[l]);
  }
  for (n = 0; n < 3; n++) {
    k = __builtin_ffs(n * 256 + 0x404100, 8);
    printf("%d%d\n", n, k);
  }
  __builtin_ia32_rdpmc(&b, 1, f);
  printf("%.3f%.3f%.3f%.3f\n", f[0], f[7], f[56], f[63]);
  d = __builtin_ia32_rdtsc;
  d = __builtin_ia32_rdtscd(&s);
  printf("%u%u%u%u%.5f%.5f\n", s.lo, s.hi, s.aux, s.aux2, d,
         __builtin_ia32_rdtsc);
  for (m = 0; m < 6; m++) {
    printf("%d%d%s\n", m, t.a[m], t.b[m]);
  }
}