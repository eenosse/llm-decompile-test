tensor_trace(double (*A)[5][20]) {
  inti, j;
  doublesum;
  sum = 0.0;
  for (i = 0; i < 2; i++) {
    sum += A[i][1][0];
  }
  for (j = 0; j < 3; j++) {
    sum += A[j][2][j + 2];
  }
  returnsum;
}