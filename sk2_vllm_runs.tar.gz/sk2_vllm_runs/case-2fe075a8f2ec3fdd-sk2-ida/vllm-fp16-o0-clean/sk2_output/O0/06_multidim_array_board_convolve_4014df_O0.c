board_convolve(int* x, inty, float* out) {
  inti, j, k, l;
  floatsum;
  intii, jj;
  for (i = 0; i < 8; i++) {
    for (j = 0; j < 8; j++) {
      sum = 0.0;
      for (k = -1; k <= 1; k++) {
        for (l = -1; l <= 1; l++) {
          ii = i + k;
          jj = j + l;
          if (ii >= 0 && ii < 8 && jj >= 0 && jj < 8) {
            sum += x[ii + 8 * y + jj * 8 + 68] * x[260 + k + 1 + 3 * (l + 1)];
          }
        }
      }
      out[i * 8 + j] = sum;
    }
  }
  return0;
}