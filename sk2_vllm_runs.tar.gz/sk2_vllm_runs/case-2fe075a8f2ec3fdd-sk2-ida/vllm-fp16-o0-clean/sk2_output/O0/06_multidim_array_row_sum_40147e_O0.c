row_sum(int* a, intn) {
  inti, j, sum = 0;
  for (i = 0; i < n; i++) {
    for (j = 0; j < 8; j++) {
      sum += a[i * 8 + j];
    }
  }
  returnsum;
}