sample_fill(unsignedchar* p, unsignedchara, shortb, unsignedcharc,
            unsignedchard, inte) {
  p[0] = (p[0] & 0xf0) | (a & 0xf);
  p[0] = (p[0] & 0x0f) | (((b << 4) & 0xf0));
  p[2] = (p[2] & 0x7f) | (c & 0x80);
  p[2] = (p[2] & 0x9f) | (((d << 5) & 0xe0));
  p[3] |= 0x04;
  *(int*)(p + 4) = e;
  p[8] = (p[8] & 0xe0) | ((a + c) & 0x1f);
}