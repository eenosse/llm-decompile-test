pte_dump(unsignedchar* p1, unsignedchar* p2) {
  unsignedlonglongparam_1;
  param_1 = *(unsignedlonglong*)p2;
  printf("%016llx%llu%llu%llu%llu%llu%llx%llx\n", param_1,
         (param_1 & 1) ? 1 : 0, (param_1 & 2) ? 1 : 0, (param_1 & 4) ? 1 : 0,
         (param_1 >> 7) & 1, (param_1 >> 63) & 1, (param_1 >> 12) & 0xfffffffff,
         (param_1 >> 60) & 0xfffffffff);
}