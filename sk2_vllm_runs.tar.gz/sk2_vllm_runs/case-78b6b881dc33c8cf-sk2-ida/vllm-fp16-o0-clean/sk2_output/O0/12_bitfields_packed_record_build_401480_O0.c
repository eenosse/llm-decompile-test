record_build(unsignedchar* packet, inttype, unsignedshortid,
             unsignedchar* data) {
  inti;
  unsignedcharchecksum = 0;
  memset(packet, 0, 27);
  packet[0] = 2;
  *(int*)(packet + 1) = type;
  *(unsignedshort*)(packet + 5) = id;
  packet[7] = (data[3] & 4) ? 0x81 : 0x01;
  *(longlong*)(packet + 8) = id + 1000000000LL * data[4];
  *(unsignedshort*)(packet + 16) = data[0] >> 4;
  *(unsignedshort*)(packet + 18) = data[2] & 0x7f;
  *(unsignedshort*)(packet + 20) = (data[2] >> 2) & 0x1f;
  *(unsignedshort*)(packet + 22) = data[8] & 0x1f;
  *(unsignedshort*)(packet + 24) = (data[0] & 0x0f) * 100;
  for (i = 0; i < 26; i++) checksum = (checksum * 31) + packet[i];
  packet[26] = checksum;
}