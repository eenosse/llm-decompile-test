pte_make(unsignedlonga, intb, intc, intd) {
  unsignedcharret[8];
  memset(ret, 0, 8);
  ret[0] |= 0x01;
  ret[0] |= b ? 0x02 : 0;
  ret[0] |= c ? 0x04 : 0;
  ret[0] |= d ? 0x80 : 0;
  ret[0] |= (a & 0x0fff) << 12;
  ret[1] |= c ? 0x80 : 0;
  ret[1] |= 0x0a;
  returnret[0];
}