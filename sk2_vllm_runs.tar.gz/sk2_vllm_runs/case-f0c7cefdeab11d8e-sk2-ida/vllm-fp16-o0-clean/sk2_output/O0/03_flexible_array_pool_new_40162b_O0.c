pool_new(intn) {
  int** a;
  a = calloc(1, sizeof(int*) * (n + 1));
  if (a == NULL) exit(1);
  a[1] = n;
  returna;
}