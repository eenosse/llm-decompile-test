main(intargc, char** argv) {
  unsignedinti;
  char* s;
  unsignedcharc;
  unsignedcharb;
  unsignedcharf;
  unsignedint* a;
  unsignedint* b;
  unsignedint* c;
  unsignedint* d;
  unsignedintj, k, l, m;
  char* e[6] = {"alpha", "beta", "gamma", "beta", "delta", "alpha"};
  unsignedcharg[48];
  for (i = 0; i < 48; i++) g[i] = i * 7 + 3;
  s = _mm_malloc(17, g, 48);
  c = s[3];
  b = s[12];
  f = s[59];
  printf("%02x%u%08x%d%02x%02x\n", c, *((unsignedint*)(s + 4)),
         *((unsignedint*)(s + 8)), b, f, s[47]);
  a = _mm_alloc_i(3, 4);
  b = _mm_alloc_i(4, 2);
  for (j = 0; j < a[0]; j++)
    for (k = 0; k < a[1]; k++)
      *(double*)_mm_at(a, j, k) = (double)(j + 1) * (double)(k + 2);
  for (l = 0; l < b[0]; l++)
    for (m = 0; m < b[1]; m++)
      *(double*)_mm_at(b, l, m) = (double)(2 * l) - (double)m;
  c = _mm_mul(a, b);
  printf("%u%u\n", c[0], c[1]);
  for (j = 0; j < c[0]; j++) {
    for (k = 0; k < c[1]; k++) printf("%8.2f", *(double*)_mm_at(c, j, k));
    putchar('\n');
  }
  d = _mm_alloc_s(8);
  for (i = 0; i < 6; i++) _mm_set(d, e[i]);
  printf("%u%u\n", d[0], d[1]);
  for (i = 0; i < d[0]; i++)
    printf("%u%08x%u%s\n", i, d[2 + 2 * i][0], d[2 + 2 * i][1],
           (char*)(d[2 + 2 * i] + 2));
  for (i = 0; i < d[0]; i++) free(d[2 + 2 * i]);
  free(d);
  free(c);
  free(b);
  free(a);
  free(s);
  return0;
}