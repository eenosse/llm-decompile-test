packet_verify(unsignedchar* p) {
  unsignedcharr = 0;
  unsignedshorta;
  unsignedintb;
  unsignedintc;
  if (*(unsignedshort*)p == 0xbec6) {
    a = *(unsignedshort*)(p + 2);
    b = *(unsignedint*)(p + 4);
    c = *(unsignedint*)(p + 8);
    if (c == func0(p + 12, b)) r = 1;
  }
  returnr;
}