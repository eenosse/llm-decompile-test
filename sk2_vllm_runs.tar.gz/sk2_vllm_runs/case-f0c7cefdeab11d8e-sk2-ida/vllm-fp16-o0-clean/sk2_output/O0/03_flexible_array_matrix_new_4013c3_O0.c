matrix_new(intn, intm) {
  int** matrix;
  matrix = calloc(1, sizeof(int*) * (n * (m + 1) + 1));
  if (matrix == NULL) exit(1);
  matrix[0] = n;
  matrix[1] = m;
  returnmatrix;
}