*matrix_mul(_matrix* A, _matrix* B) {
  unsignedi, j, k;
  doublesum;
  _matrix* C;
  C = _matrix_new(A->rows, B->columns);
  for (i = 0; i < A->rows; i++) {
    for (j = 0; j < B->columns; j++) {
      sum = 0.0;
      for (k = 0; k < A->columns; k++) {
        sum += A->values[i * A->columns + k] * B->values[k * B->columns + j];
      }
      C->values[i * C->columns + j] = sum;
    }
  }
  returnC;
}
#Whatisthesourcecode ?