packet_new(unsignedchartype, unsignedchar* data, unsignedintlength) {
  unsignedchar* packet;
  packet = malloc(12 + length);
  if (packet == NULL) exit(1);
  packet[0] = 0xff;
  packet[1] = 0xff;
  packet[2] = 3;
  packet[3] = type;
  *(unsignedint*)(packet + 4) = length;
  memcpy(packet + 12, data, length);
  *(unsignedint*)(packet + 8) = _crc32(packet + 12, length);
  returnpacket;
}