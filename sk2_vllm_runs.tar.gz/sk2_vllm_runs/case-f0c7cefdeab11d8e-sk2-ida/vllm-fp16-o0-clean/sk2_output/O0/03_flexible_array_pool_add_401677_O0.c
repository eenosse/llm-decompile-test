*pool_add(_symbol_table* table, constchar* name) {
  for (unsignedi = 0; i < table->count; i++) {
    if (strcmp(table->symbols[i]->name, name) == 0) {
      returntable->symbols[i];
    }
  }
  if (table->count == table->size) {
    returnNULL;
  }
  _symbol* symbol = _new_symbol(name);
  table->symbols[table->count++] = symbol;
  returnsymbol;
}