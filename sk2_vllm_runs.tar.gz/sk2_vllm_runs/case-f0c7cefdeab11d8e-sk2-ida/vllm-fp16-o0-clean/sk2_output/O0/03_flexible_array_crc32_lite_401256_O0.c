crc32_lite(unsignedchar* T, unsignedlonglongN) {
  inti;
  intj;
  unsignedlonglongc;
  c = 0xffffffffffffffff;
  for (i = 0; i < N; i++) {
    c = c ^ T[i];
    for (j = 0; j < 8; j++) {
      c = (c >> 1) ^ (-(c & 1)) & 0xedb88320;
    }
  }
  c = ~c;
  returnc;
}