intern_new(constchar* str) {
  unsignedinthash;
  unsignedintlen;
  unsignedinti;
  unsignedint* ret;
  len = strlen(str);
  ret = malloc(len + 9);
  hash = 0x811c9dc5;
  if (ret == NULL) exit(1);
  memcpy(ret + 2, str, len + 1);
  *(unsignedint*)(ret + 1) = len;
  for (i = 0; i < len; ++i) hash = (hash * 16777619) ^ str[i];
  *(unsignedint*)ret = hash;
  returnret;
}