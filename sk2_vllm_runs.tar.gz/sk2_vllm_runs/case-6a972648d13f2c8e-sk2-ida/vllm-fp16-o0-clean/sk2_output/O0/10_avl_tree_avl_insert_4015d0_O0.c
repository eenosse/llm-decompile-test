avl_insert(unsignedchar** ptr, unsignedint* len) {
  unsignedchar* ret;
  ret = func2((unsignedchar**)ptr, *ptr, *len, len);
  *ptr = ret;
}