avl_erase(char** argv, intargc) {
  char* arg;
  arg = func2(argv, *argv, argc);
  *argv = arg;
}