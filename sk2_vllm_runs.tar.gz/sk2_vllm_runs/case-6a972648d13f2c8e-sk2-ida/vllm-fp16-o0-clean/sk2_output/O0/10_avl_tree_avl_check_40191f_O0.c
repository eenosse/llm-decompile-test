avl_check(node* n) {
  inti;
  if (n == NULL) return1;
  i = intfunc2(n);
  if (i < -1 || i > 1) return0;
  returnintfunc1(n->left) && intfunc1(n->right);
}