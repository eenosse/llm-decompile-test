rotate(void** a, int i) {
  void** b;
  b = a[1 - i + 8];
  a[1 - i + 8] = b[i + 8];
  b[i + 8] = a;
  _free(a);
  _free(b);
  returnb;
}