avl_insert_rec(int** p, int* t, intkey, int* value) {
  if (t == NULL) {
    p[1]++;
    return__binary_search_tree_insert_new_node(key, value);
  }
  if (key == t[0]) {
    for (inti = 1; i < 7; i++) {
      t[i] = value[i - 1];
    }
    returnt;
  }
  intleft = key > t[0];
  t[8 + left] = __binary_search_tree_insert(p, t[8 + left], key, value);
  return__binary_search_tree_insert_rebalance(p, t);
}