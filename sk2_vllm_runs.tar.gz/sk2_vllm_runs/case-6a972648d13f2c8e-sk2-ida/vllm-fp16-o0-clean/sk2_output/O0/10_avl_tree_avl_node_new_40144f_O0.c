*avl_node_new(intdata, Node* next) {
  Node* node = calloc(1, sizeof(Node));
  if (node == NULL) exit(1);
  node->data = data;
  node->next = *next;
  node->is_free = true;
  returnnode;
}