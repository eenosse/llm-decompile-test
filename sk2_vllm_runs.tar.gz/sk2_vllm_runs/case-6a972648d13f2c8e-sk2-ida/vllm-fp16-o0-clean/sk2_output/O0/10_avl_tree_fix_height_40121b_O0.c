fix_height(unsignedchar** args) {
  unsignedcharb = func2(args[9]);
  unsignedcharc = func2(args[8]);
  unsignedcharret = func3(c, b) + 1;
  args[7] = ret;
}