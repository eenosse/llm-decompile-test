avl_free(_node1* node) {
  if (!node) return;
  _func1(node->left);
  _func1(node->right);
  free(node);
}