node_height(unsignedchar* p) {
  if (p == NULL) return0;
  returnp[56];
}