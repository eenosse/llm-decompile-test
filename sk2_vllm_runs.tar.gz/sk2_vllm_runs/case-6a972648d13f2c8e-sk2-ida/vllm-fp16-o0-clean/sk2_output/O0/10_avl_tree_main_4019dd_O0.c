main(intargc, char** argv) {
  Tt t;
  memset(&t, 0, sizeof(t));
  for (inti = 0; i < 11; i++) Tt_add(&t, s[i]);
  Tt_print(t.s, 0);
  printf("%zu%s%d%d\n", t.n, t.s + 12, t.s[12], Tt_count(t.s));
  printf("%u%u%u%u\n", t.a, t.b, t.c, t.d);
  unsigned* p = Tt_find(t.s, 6000000);
  unsignedx = p ? *p : 0;
  printf("%s%u\n", p ? (char*)p + 3 : "-", x);
  Tt_remove(&t, 8982000);
  Tt_remove(&t, 2161000);
  printf("%zu%s%d\n", t.n, t.s + 12, Tt_count(t.s));
  Tt_print(t.s, 0);
  Tt_free(t.s);
  return0;
}