avl_print(node* root, intlevel) {
  if (root != NULL) {
    func1(root->left, level + 1);
    printf("%d%s%s%u%d%d%.2f%.2f\n", level, root->name, root->type, root->size,
           root->line, func2(root), root->level, root->offset);
    func1(root->right, level + 1);
  }
}