*avl_find_ge(Node* node, intkey) {
  Node* result = NULL;
  while (node != NULL) {
    if (node->key >= key) {
      result = node;
      node = node->left;
    } else {
      node = node->right;
    }
  }
  returnresult;
}