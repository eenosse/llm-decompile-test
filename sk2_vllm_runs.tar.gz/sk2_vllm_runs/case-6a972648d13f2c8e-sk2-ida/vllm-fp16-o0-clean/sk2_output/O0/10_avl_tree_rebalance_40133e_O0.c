rebalance(int* counters, Node* node) {
  _print_node(node);
  intbalance = _get_balance(node);
  if (balance > 1) {
    if (_get_balance(node->right) < 0) {
      counters[6]++;
      node->right = _rotate(node->right, 1);
    } else {
      counters[4]++;
    }
    _rotate(node, 0);
  }
  elseif(balance < -1) {
    if (_get_balance(node->left) > 0) {
      counters[7]++;
      node->left = _rotate(node->left, 0);
    } else {
      counters[5]++;
    }
    _rotate(node, 1);
  }
}