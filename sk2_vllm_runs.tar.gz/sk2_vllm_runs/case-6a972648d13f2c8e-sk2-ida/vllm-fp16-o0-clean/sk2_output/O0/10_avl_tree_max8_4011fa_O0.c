max8(chararg1, chararg2) {
  charlocal1;
  local1 = arg1;
  if (arg2 < arg1) {
    local1 = arg2;
  }
  returnlocal1;
}